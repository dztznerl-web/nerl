"""Power-ups. Balance rules: earned only through stage challenges, one held at a time, short durations,
no ability guarantees a win (teleport lands on a random safe tile, lucky colour only reveals the target early)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

ABILITY_PHASES_BLOCKED = {"resolve"}   # teleport & co. may not be used while the floor is dropping


@dataclass(frozen=True)
class Ability:
    id: str
    name_ar: str
    name_en: str
    weight: int
    duration: float = 0.0     # 0 = instant
    effect: str | None = None  # timed effect name stored on the player
    instant: Callable | None = None


def _dash(m, p, now):
    d = (math.sin(p.facing), math.cos(p.facing))
    p.vx, p.vz = d[0] * 17.0, d[1] * 17.0
    p.add_effect("dashing", now + 0.25)
    m.emit({"e": "dash", "u": p.uid})


def _freeze(m, p, now):
    best, best_d = None, 8.0
    for o in m.players.values():
        if o is p or not o.alive or o.has("shield", now) or o.freeze_immune_until > now:
            continue
        d = math.hypot(o.x - p.x, o.z - p.z)
        if d < best_d:
            best, best_d = o, d
    if best is None:
        return False  # not consumed when nobody is in range
    best.add_effect("frozen", now + 1.5)
    best.freeze_immune_until = now + 1.5 + 4.0
    best.vx = best.vz = 0.0
    m.emit({"e": "freeze", "u": best.uid, "by": p.uid})
    return True


def _teleport(m, p, now):
    if m.phase not in ("scramble", "select"):
        return False
    near = [i for i in m.arena.solid_indices()
            if 3.0 < math.hypot(m.arena.tile_center(i, now)[0] - p.x, m.arena.tile_center(i, now)[1] - p.z) < 10.0]
    if not near:
        return False
    idx = m.rng.choice(near)
    p.x, p.z = m.arena.tile_center(idx, now)
    p.y, p.vy, p.grounded = 0.0, 0.0, True
    m.emit({"e": "teleport", "u": p.uid, "x": round(p.x, 2), "z": round(p.z, 2)})
    return True


ABILITIES: dict[str, Ability] = {a.id: a for a in [
    Ability("speed", "سرعة", "Speed", 12, 6.0, "speed"),
    Ability("shield", "درع", "Shield", 10, 5.0, "shield"),
    Ability("double_jump", "قفزة مزدوجة", "Double Jump", 12, 10.0, "double_jump"),
    Ability("dash", "اندفاع", "Dash", 10, instant=_dash),
    Ability("push_boost", "دفع قوي", "Push Boost", 8, 6.0, "push_boost"),
    Ability("anti_push", "مقاومة الدفع", "Anti Push", 8, 8.0, "anti_push"),
    Ability("freeze", "تجميد", "Freeze", 5, instant=_freeze),
    Ability("invisibility", "اختفاء", "Invisibility", 6, 5.0, "invisible"),
    Ability("teleport", "انتقال", "Teleport", 5, instant=_teleport),
    Ability("slow_motion", "حركة بطيئة", "Slow Motion", 5, 6.0, "slowmo"),
    Ability("lucky_color", "اللون المحظوظ", "Lucky Color", 5, effect="lucky"),   # lasts until stage end
    Ability("mega_jump", "قفزة عملاقة", "Mega Jump", 7, 8.0, "mega_jump"),
    Ability("second_chance", "فرصة ثانية", "Second Chance", 3, 12.0, "second_chance"),
]}


def roll_ability(rng, exclude: str | None = None) -> str:
    pool = [a for a in ABILITIES.values() if a.id != exclude]
    return rng.choices([a.id for a in pool], weights=[a.weight for a in pool], k=1)[0]


def use_ability(match, player, now: float, duration_scale: float = 1.0) -> bool:
    """Consume the held ability. Returns True if used."""
    ab = ABILITIES.get(player.held_ability or "")
    if ab is None or not player.alive or player.has("frozen", now) or match.phase in ABILITY_PHASES_BLOCKED:
        return False
    if ab.instant is not None:
        if ab.instant(match, player, now) is False:
            return False
    if ab.effect:
        until = now + ab.duration * duration_scale if ab.duration else match.stage_end_time(now)
        player.add_effect(ab.effect, until)
    player.held_ability = None
    match.emit({"e": "ability", "u": player.uid, "a": ab.id})
    return True
