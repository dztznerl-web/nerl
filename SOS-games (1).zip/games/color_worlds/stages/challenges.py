"""Per-stage challenges. Completing one earns a power-up (see Match.grant_challenge)."""
from __future__ import annotations

import math

from games.color_worlds.engine.arena import Platform
from games.color_worlds.mechanics.base import knock


class Challenge:
    kind = "base"

    def __init__(self, match, stage, rng):
        self.match, self.stage, self.rng = match, stage, rng
        self.target = stage.challenge_target

    def on_round_start(self, now: float) -> None: ...
    def on_select_start(self, now: float) -> None: ...
    def on_resolve_start(self, now: float) -> None: ...
    def on_round_survived(self, player) -> list[int]:
        return []

    def update(self, dt: float, now: float) -> list[int]:
        return []

    def describe(self) -> dict:
        return {"kind": self.kind, "target": self.target}

    def replay_events(self) -> list[dict]:
        return []

    def snapshot(self, now: float) -> dict | None:
        return None

    def _candidates(self):
        return self.match.players.values()

    def _random_tile_center(self, now):
        solid = self.match.arena.solid_indices()
        return self.match.arena.tile_center(self.rng.choice(solid), now) if solid else (0.0, 0.0)


class SurviveRounds(Challenge):
    kind = "survive_rounds"

    def on_round_survived(self, player):
        player.challenge_progress += 1
        return [player.uid] if player.challenge_progress >= self.target and not player.challenge_done else []


class Collect(Challenge):
    kind = "collect"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        self.items: list[list[float]] = []

    def on_round_start(self, now):
        count = self.target + max(2, len(self.match.alive()) // 3)
        self.items = [list(self._random_tile_center(now)) for _ in range(count)]
        self.match.emit({"e": "items", "items": [[round(x, 2), round(z, 2)] for x, z in self.items]})

    def on_resolve_start(self, now):
        self.items = []
        self.match.emit({"e": "items", "items": []})

    def replay_events(self):
        return [{"e": "items", "items": [[round(x, 2), round(z, 2)] for x, z in self.items]}] if self.items else []

    def update(self, dt, now):
        done = []
        for p in self.match.alive():
            if p.challenge_done or p.y > 1.6:
                continue
            for it in list(self.items):
                if math.hypot(p.x - it[0], p.z - it[1]) < 1.1:
                    self.items.remove(it)
                    p.challenge_progress += 1
                    self.match.emit({"e": "pickup", "u": p.uid, "n": p.challenge_progress})
                    if p.challenge_progress >= self.target:
                        done.append(p.uid)
                        break
        if done or len(self.items) < 1:
            pass
        return done

    def snapshot(self, now):
        return None


class ReachZone(Challenge):
    kind = "reach_zone"
    RADIUS = 1.9

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        self.zone = (0.0, 0.0)
        self.active = False

    def on_round_start(self, now):
        self.zone = self._random_tile_center(now)
        self.active = True
        self.match.emit({"e": "zone", "x": round(self.zone[0], 2), "z": round(self.zone[1], 2), "r": self.RADIUS})

    def on_resolve_start(self, now):
        self.active = False
        self.match.emit({"e": "zone", "x": None})

    def replay_events(self):
        return [{"e": "zone", "x": round(self.zone[0], 2), "z": round(self.zone[1], 2), "r": self.RADIUS}] if self.active else []

    def update(self, dt, now):
        if not self.active:
            return []
        return [p.uid for p in self.match.alive() if not p.challenge_done and p.grounded
                and math.hypot(p.x - self.zone[0], p.z - self.zone[1]) < self.RADIUS]


class ReachPlatform(Challenge):
    kind = "reach_platform"

    def on_round_start(self, now):
        cx, cz = self._random_tile_center(now)
        a = self.match.arena
        limit = a.half_extent - 4.0
        cx = max(-limit, min(limit - 2.6, cx))
        a.platforms = [Platform(cx, cz, 1.2, 1.2), Platform(cx + 2.6, cz, 1.2, 2.4)]
        self.match.emit({"e": "platforms", "p": [[round(p.x, 2), round(p.z, 2), p.half, p.top] for p in a.platforms]})

    def replay_events(self):
        a = self.match.arena
        return [{"e": "platforms", "p": [[p.x, p.z, p.half, p.top] for p in a.platforms]}] if a.platforms else []

    def on_resolve_start(self, now):
        # platforms retract so they can never be used to dodge the falling floor
        self.match.arena.platforms = []
        self.match.emit({"e": "platforms", "p": []})

    def update(self, dt, now):
        return [p.uid for p in self.match.alive() if not p.challenge_done and p.grounded and p.y >= 2.2]


class JumpCount(Challenge):
    """Rolling bars sweep across the arena; clear them by jumping."""
    kind = "jump_count"
    SPEED = 6.0

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        self.bars: list[dict] = []
        self.spawn_queue: list[float] = []
        self.last_side: dict[tuple[int, int], int] = {}

    def on_select_start(self, now):
        n = 2 + self.stage.stage_in_world
        self.spawn_queue = [now + k * 1.0 for k in range(n)]
        self.bars = []
        self._next_id = getattr(self, "_next_id", 0)

    def update(self, dt, now):
        half = self.match.arena.half_extent
        while self.spawn_queue and now >= self.spawn_queue[0]:
            self.spawn_queue.pop(0)
            direction = 1 if self.rng.random() < 0.5 else -1
            self._next_id += 1
            self.bars.append({"id": self._next_id, "z": -half * direction, "dir": direction})
        done = []
        for bar in list(self.bars):
            bar["z"] += bar["dir"] * self.SPEED * dt
            if abs(bar["z"]) > half + 1:
                self.bars.remove(bar)
                continue
            for p in self.match.alive():
                if abs(p.x) > half:
                    continue
                side = 1 if p.z > bar["z"] else -1
                key = (bar["id"], p.uid)
                prev = self.last_side.get(key)
                self.last_side[key] = side
                if prev is None or prev == side or abs(p.z - bar["z"]) > 1.2:
                    continue
                if p.y >= 0.85:
                    if not p.challenge_done:
                        p.challenge_progress += 1
                        self.match.emit({"e": "cleared", "u": p.uid, "n": p.challenge_progress})
                        if p.challenge_progress >= self.target:
                            done.append(p.uid)
                else:
                    knock(p, 0.0, bar["dir"], 6.0, 3.0, now, 0.6)
                    self.match.emit({"e": "hit", "u": p.uid, "src": "bar"})
        return done

    def on_resolve_start(self, now):
        self.spawn_queue = []

    def snapshot(self, now):
        return {"bars": [[round(b["z"], 2), b["dir"]] for b in self.bars]} if self.bars else None


CHALLENGES = {c.kind: c for c in (SurviveRounds, Collect, ReachZone, ReachPlatform, JumpCount)}
