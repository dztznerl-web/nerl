"""All tunable numbers for Color Worlds in one place (difficulty curve, physics, timings).

Developers can override a safe subset at runtime with /gameconfig KEY VALUE (see OVERRIDABLE).
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

TICK_RATE = 20
DT = 1.0 / TICK_RATE
MAX_PLAYERS = 30
MIN_PLAYERS = 2
TILE_SIZE = 3.0
PLAYER_RADIUS = 0.5
FALL_KILL_Y = -10.0
TOTAL_WORLDS = 7
STAGES_PER_WORLD = 3
TOTAL_STAGES = TOTAL_WORLDS * STAGES_PER_WORLD  # 21

COLORS = ["#ff3b5c", "#2d9cff", "#2ecc71", "#ffd23f", "#b15cff", "#ff8a2b", "#19d3c5", "#ff6fcf"]
COLOR_NAMES_AR = ["احمر", "ازرق", "اخضر", "اصفر", "بنفسجي", "برتقالي", "تركوازي", "وردي"]


@dataclass(frozen=True)
class Physics:
    gravity: float = -28.0
    jump_velocity: float = 10.0
    walk_speed: float = 5.0
    run_speed: float = 8.0
    accel: float = 45.0
    friction: float = 10.0          # velocity damping per second when no input (low = slippery)
    push_range: float = 1.9
    push_cooldown: float = 1.5
    push_impulse: float = 11.0
    push_cone_cos: float = 0.25     # target must be roughly in front
    step_height: float = 0.35


DEFAULT_PHYSICS = Physics()


@dataclass(frozen=True)
class Tuning:
    """Server-wide gameplay knobs. Changing them never needs code edits."""
    lobby_countdown: float = 3.0
    stage_intro: float = 3.5
    scramble_time: float = 1.6      # target hidden during this window (Lucky Color reveals it)
    resolve_time: float = 3.0
    intermission: float = 2.5
    warning_time: float = 0.6       # tiles flash before falling
    disconnect_grace: float = 30.0  # seconds a dropped player keeps their slot
    ability_duration_scale: float = 1.0
    reward_scale: float = 1.0
    challenge_enabled: bool = True


OVERRIDABLE = {
    "stage_intro": (1.0, 10.0), "scramble_time": (0.5, 4.0), "resolve_time": (1.5, 6.0),
    "intermission": (1.0, 8.0), "disconnect_grace": (5.0, 120.0), "ability_duration_scale": (0.3, 3.0),
    "reward_scale": (0.0, 5.0), "lobby_countdown": (1.0, 10.0),
}
DEFAULT_TUNING = Tuning()


def validate_override(key: str, value: str) -> float:
    if key not in OVERRIDABLE:
        raise ValueError(f"مفتاح غير مدعوم. المتاح: {', '.join(sorted(OVERRIDABLE))}")
    try:
        v = float(value)
    except ValueError as exc:
        raise ValueError("القيمة لازم تكون رقم") from exc
    lo, hi = OVERRIDABLE[key]
    if not lo <= v <= hi:
        raise ValueError(f"{key} لازم يكون بين {lo} و{hi}")
    return v


def apply_overrides(base: Tuning, overrides: dict[str, str]) -> Tuning:
    changes = {}
    for k, raw in overrides.items():
        try:
            changes[k] = validate_override(k, raw)
        except ValueError:
            continue  # ignore invalid stored values rather than crash a match
    return replace(base, **changes)


@dataclass(frozen=True)
class StageConfig:
    number: int                 # 1..21 overall
    world_index: int            # 0..6
    stage_in_world: int         # 1..3
    colors: int                 # how many distinct colors on the floor
    rounds: int
    select_time: float          # seconds to reach the target colour after it is revealed
    shuffle_interval: float     # scramble speed (seconds between colour reshuffles)
    platform_amplitude: float   # moving-row amplitude in tiles-units
    hazard_level: float         # 0..1 intensity of the world's hazards
    challenge: str
    challenge_target: int


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


CHALLENGES_BY_STAGE = ["survive_rounds", "collect", "reach_zone", "jump_count", "reach_platform"]


def build_stage(number: int) -> StageConfig:
    """Difficulty curve: every stage is a little harder than the last (less time, more colours,
    faster scramble, more movement and hazards). Stage 1 is gentle, stage 21 is tough but fair."""
    if not 1 <= number <= TOTAL_STAGES:
        raise ValueError("stage out of range")
    n = number - 1
    t = n / (TOTAL_STAGES - 1)
    world_index, in_world = divmod(n, STAGES_PER_WORLD)
    challenge = CHALLENGES_BY_STAGE[n % len(CHALLENGES_BY_STAGE)]
    target = {"survive_rounds": 2 + in_world, "collect": 3 + in_world, "reach_zone": 1, "jump_count": 3 + in_world * 2,
              "reach_platform": 1}[challenge]
    return StageConfig(
        number=number, world_index=world_index, stage_in_world=in_world + 1,
        colors=int(round(_lerp(3, 8, t))), rounds=3 + in_world,
        select_time=round(_lerp(6.5, 2.4, t), 2), shuffle_interval=round(_lerp(0.9, 0.25, t), 2),
        platform_amplitude=round(_lerp(0.0, 2.2, t), 2), hazard_level=round(_lerp(0.15, 1.0, t), 2),
        challenge=challenge, challenge_target=target)
