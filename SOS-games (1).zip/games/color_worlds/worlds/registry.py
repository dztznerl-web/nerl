"""World definitions (data-driven). To add a world: append a WorldDef here and give it a visual theme in
frontend/src/worlds.js. No engine code changes are needed unless it introduces a brand-new mechanic."""
from __future__ import annotations

from dataclasses import dataclass, field

from games.color_worlds.config import DEFAULT_PHYSICS, Physics


@dataclass(frozen=True)
class WorldDef:
    id: str
    name_en: str
    name_ar: str
    physics: Physics
    mechanics: tuple[str, ...]            # ids from games.color_worlds.mechanics registry
    theme: dict = field(default_factory=dict)  # sent to the client for visuals only


WORLDS: list[WorldDef] = [
    WorldDef("neon_city", "Neon City", "مدينة النيون", DEFAULT_PHYSICS, ("sweepers",),
             {"sky": "#0a0020", "fog": "#1a0040", "ground": "#120033", "glow": "#00f0ff", "effects": "electric"}),
    WorldDef("lava_kingdom", "Lava Kingdom", "مملكة الحمم", DEFAULT_PHYSICS, ("moving_platforms", "geysers"),
             {"sky": "#2a0800", "fog": "#4a1200", "ground": "#1c0a05", "glow": "#ff5a1f", "effects": "heat"}),
    WorldDef("ice_world", "Ice World", "عالم الجليد", Physics(friction=1.6, accel=18.0), ("moving_platforms",),
             {"sky": "#bfe8ff", "fog": "#dff4ff", "ground": "#9fd4f0", "glow": "#ffffff", "effects": "snow"}),
    WorldDef("sky_islands", "Sky Islands", "جزر السماء", DEFAULT_PHYSICS, ("wind", "moving_platforms"),
             {"sky": "#6ec6ff", "fog": "#cfeeff", "ground": "#7bd36b", "glow": "#ffffff", "effects": "clouds"}),
    WorldDef("candy_land", "Candy Land", "ارض الحلوى", Physics(jump_velocity=11.5), ("bounce_pads",),
             {"sky": "#ffd1f0", "fog": "#ffe6f7", "ground": "#ff9fd8", "glow": "#fff29e", "effects": "sprinkles"}),
    WorldDef("cyber_arena", "Cyber Arena", "ساحة السايبر", DEFAULT_PHYSICS, ("sweepers", "moving_platforms"),
             {"sky": "#00121f", "fog": "#002b45", "ground": "#001a2b", "glow": "#00ffa6", "effects": "digital"}),
    WorldDef("ancient_temple", "Ancient Temple", "المعبد القديم", DEFAULT_PHYSICS, ("traps",),
             {"sky": "#e8c98a", "fog": "#d9b779", "ground": "#8a6b3f", "glow": "#ffd27a", "effects": "dust"}),
]


def get_world(index: int) -> WorldDef:
    return WORLDS[index]


def world_by_id(world_id: str) -> WorldDef:
    return next(w for w in WORLDS if w.id == world_id)
