from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class InputState:
    mx: float = 0.0
    mz: float = 0.0
    run: bool = False
    seq: int = 0


@dataclass
class PlayerStats:
    stages_survived: int = 0
    rounds_survived: int = 0
    challenges_completed: int = 0
    pushes_landed: int = 0
    jumps: int = 0


@dataclass
class PlayerState:
    uid: int
    name: str
    character: dict
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    facing: float = 0.0
    grounded: bool = True
    alive: bool = True
    left: bool = False                 # quit voluntarily or grace expired
    connected: bool = True
    disconnected_at: float | None = None
    input: InputState = field(default_factory=InputState)
    jump_pressed: bool = False
    push_pressed: bool = False
    ability_pressed: bool = False
    jumps_used: int = 0
    push_ready_at: float = 0.0
    effects: dict[str, float] = field(default_factory=dict)   # name -> expires_at (match time)
    held_ability: str | None = None
    freeze_immune_until: float = 0.0
    hit_cooldown_until: float = 0.0    # hazard knockback cooldown
    elimination_group: int | None = None   # larger = survived longer
    challenge_done: bool = False
    challenge_progress: int = 0
    anim: str = "idle"
    stats: PlayerStats = field(default_factory=PlayerStats)

    def has(self, effect: str, now: float) -> bool:
        return self.effects.get(effect, 0.0) > now

    def add_effect(self, effect: str, until: float) -> None:
        self.effects[effect] = until

    def clean_effects(self, now: float) -> None:
        for k in [k for k, v in self.effects.items() if v <= now]:
            del self.effects[k]

    @property
    def speed(self) -> float:
        return math.hypot(self.vx, self.vz)
