from __future__ import annotations

import math
from dataclasses import dataclass

from games.color_worlds.config import TILE_SIZE

SOLID, WARNING, FALLEN = 0, 1, 2


@dataclass
class Platform:
    x: float
    z: float
    half: float
    top: float


class Arena:
    """Square grid of tiles centred on (0,0). Rows may slide horizontally (moving platforms)."""

    def __init__(self, n: int, ts: float = TILE_SIZE):
        self.n, self.ts = n, ts
        self.colors = [0] * (n * n)
        self.state = [SOLID] * (n * n)
        self.pads: set[int] = set()
        self.platforms: list[Platform] = []
        self.row_amp = 0.0
        self.row_freq = 0.8
        self.moving_rows: dict[int, float] = {}   # row -> phase

    @property
    def half_extent(self) -> float:
        return self.n * self.ts / 2

    def row_offset(self, row: int, now: float) -> float:
        phase = self.moving_rows.get(row)
        return 0.0 if phase is None or self.row_amp == 0 else self.row_amp * math.sin(self.row_freq * now + phase)

    def tile_index_at(self, x: float, z: float, now: float) -> int | None:
        j = math.floor(z / self.ts + self.n / 2)
        if not 0 <= j < self.n:
            return None
        i = math.floor((x - self.row_offset(j, now)) / self.ts + self.n / 2)
        return j * self.n + i if 0 <= i < self.n else None

    def tile_center(self, idx: int, now: float) -> tuple[float, float]:
        j, i = divmod(idx, self.n)
        return ((i - (self.n - 1) / 2) * self.ts + self.row_offset(j, now), (j - (self.n - 1) / 2) * self.ts)

    def support_height(self, x: float, z: float, y: float, step: float, now: float) -> float | None:
        best: float | None = None
        idx = self.tile_index_at(x, z, now)
        if idx is not None and self.state[idx] != FALLEN and y >= -step:
            best = 0.0
        for p in self.platforms:
            if abs(x - p.x) <= p.half and abs(z - p.z) <= p.half and p.top <= y + step:
                if best is None or p.top > best:
                    best = p.top
        return best

    def solid_indices(self) -> list[int]:
        return [i for i, s in enumerate(self.state) if s != FALLEN]

    def nearest_solid(self, x: float, z: float, now: float) -> int | None:
        best, best_d = None, 1e18
        for i in self.solid_indices():
            cx, cz = self.tile_center(i, now)
            d = (cx - x) ** 2 + (cz - z) ** 2
            if d < best_d:
                best, best_d = i, d
        return best
