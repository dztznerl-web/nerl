"""Server-side movement physics. Clients send only inputs; positions are always computed here."""
from __future__ import annotations

import math

from games.color_worlds.config import FALL_KILL_Y, PLAYER_RADIUS, Physics
from games.color_worlds.engine.arena import Arena
from games.color_worlds.engine.state import PlayerState

MAX_COORD = 400.0


def _approach(v: float, target: float, max_delta: float) -> float:
    if v < target:
        return min(v + max_delta, target)
    return max(v - max_delta, target)


def step_player(p: PlayerState, arena: Arena, phys: Physics, dt: float, now: float, dur_scale: float = 1.0) -> list[dict]:
    """Advance one player by dt. Returns events (jump / land / pad)."""
    events: list[dict] = []
    p.clean_effects(now)
    frozen = p.has("frozen", now)
    dashing = p.has("dashing", now)

    mx, mz = p.input.mx, p.input.mz
    mag = math.hypot(mx, mz)
    if mag > 1.0:
        mx, mz, mag = mx / mag, mz / mag, 1.0
    if frozen:
        mx = mz = mag = 0.0

    speed_mult = (1.5 if p.has("speed", now) else 1.0) * (0.7 if p.has("slowmo", now) else 1.0)
    top_speed = (phys.run_speed if p.input.run else phys.walk_speed) * speed_mult

    if not dashing:
        accel = phys.accel if p.grounded else phys.accel * 0.4
        if mag > 0.05:
            tvx, tvz = mx * top_speed, mz * top_speed
            dvx, dvz = tvx - p.vx, tvz - p.vz
            dist = math.hypot(dvx, dvz)
            lim = accel * dt
            if dist > lim:
                dvx, dvz = dvx / dist * lim, dvz / dist * lim
            p.vx += dvx
            p.vz += dvz
            target_face = math.atan2(mx, mz)
            diff = (target_face - p.facing + math.pi) % (2 * math.pi) - math.pi
            p.facing += max(-12 * dt, min(12 * dt, diff))
        else:
            damp = max(0.0, 1.0 - (phys.friction if p.grounded else 0.3) * dt)
            p.vx *= damp
            p.vz *= damp

    # jumping (edge-triggered input, validated here)
    if p.jump_pressed and not frozen:
        jm = phys.jump_velocity * (1.6 if p.has("mega_jump", now) else 1.0)
        if p.grounded:
            p.vy, p.grounded, p.jumps_used = jm, False, 1
            p.stats.jumps += 1
            events.append({"e": "jump", "u": p.uid})
        elif p.has("double_jump", now) and p.jumps_used < 2:
            p.vy, p.jumps_used = jm * 0.92, 2
            p.stats.jumps += 1
            events.append({"e": "jump", "u": p.uid, "d": 1})
    p.jump_pressed = False

    g = phys.gravity * (0.4 if p.has("slowmo", now) else 1.0)
    p.vy += g * dt
    old_y = p.y
    p.x = max(-MAX_COORD, min(MAX_COORD, p.x + p.vx * dt))
    p.z = max(-MAX_COORD, min(MAX_COORD, p.z + p.vz * dt))
    p.y += p.vy * dt

    sup = arena.support_height(p.x, p.z, old_y, phys.step_height, now)
    if p.vy <= 0 and sup is not None and p.y <= sup:
        was_air = not p.grounded
        p.y, p.vy, p.grounded, p.jumps_used = sup, 0.0, True, 0
        idx = arena.tile_index_at(p.x, p.z, now)
        if idx is not None and idx in arena.pads and sup == 0.0:
            p.vy, p.grounded, p.jumps_used = phys.jump_velocity * 1.35, False, 1
            events.append({"e": "pad", "u": p.uid})
        elif was_air:
            events.append({"e": "land", "u": p.uid})
    else:
        p.grounded = False

    # second chance: rescue once from falling
    if p.has("second_chance", now) and p.y < -1.5 and p.vy < 0:
        idx = arena.nearest_solid(p.x, p.z, now)
        if idx is not None:
            p.x, p.z = arena.tile_center(idx, now)
            p.y, p.vy, p.vx, p.vz, p.grounded = 0.0, 0.0, 0.0, 0.0, True
            del p.effects["second_chance"]
            events.append({"e": "rescued", "u": p.uid})

    p.anim = _anim(p, frozen)
    return events


def _anim(p: PlayerState, frozen: bool) -> str:
    if frozen:
        return "frozen"
    if p.y < -0.6 and not p.grounded:
        return "fall"
    if not p.grounded:
        return "jump"
    s = p.speed
    return "run" if s > 6.2 else "walk" if s > 0.6 else "idle"


def separate_players(players: list[PlayerState]) -> None:
    """Soft collision so players cannot stack inside each other."""
    live = [p for p in players if p.alive and p.y > -1.0]
    min_d = PLAYER_RADIUS * 2
    for a_i in range(len(live)):
        a = live[a_i]
        for b_i in range(a_i + 1, len(live)):
            b = live[b_i]
            if abs(a.y - b.y) > 1.0:
                continue
            dx, dz = b.x - a.x, b.z - a.z
            d2 = dx * dx + dz * dz
            if d2 >= min_d * min_d:
                continue
            d = math.sqrt(d2)
            if d < 1e-6:
                dx, dz, d = 1.0, 0.0, 1.0
            overlap = (min_d - d) / 2
            nx, nz = dx / d, dz / d
            a.x -= nx * overlap
            a.z -= nz * overlap
            b.x += nx * overlap
            b.z += nz * overlap


def is_dead(p: PlayerState) -> bool:
    return p.y < FALL_KILL_Y
