"""Pushing. Fully server-side: range, facing cone, cooldown, shield / anti-push, boost are all checked here."""
from __future__ import annotations

import math

from games.color_worlds.config import PLAYER_RADIUS, Physics
from games.color_worlds.engine.state import PlayerState

MISS_COOLDOWN = 0.6


def try_push(pusher: PlayerState, players: dict[int, PlayerState], phys: Physics, now: float) -> list[dict]:
    if not pusher.alive or pusher.has("frozen", now) or now < pusher.push_ready_at:
        return []
    fx, fz = math.sin(pusher.facing), math.cos(pusher.facing)
    best, best_d = None, phys.push_range + PLAYER_RADIUS
    for o in players.values():
        if o is pusher or not o.alive or abs(o.y - pusher.y) > 1.2:
            continue
        dx, dz = o.x - pusher.x, o.z - pusher.z
        d = math.hypot(dx, dz)
        if d > best_d or d < 1e-6:
            continue
        if (dx * fx + dz * fz) / d < phys.push_cone_cos:
            continue
        best, best_d = o, d
    if pusher.has("invisible", now):
        del pusher.effects["invisible"]          # attacking reveals you
    if best is None:
        pusher.push_ready_at = now + MISS_COOLDOWN
        return [{"e": "push", "a": pusher.uid, "b": None}]
    pusher.push_ready_at = now + phys.push_cooldown
    dx, dz = best.x - pusher.x, best.z - pusher.z
    d = math.hypot(dx, dz) or 1.0
    if best.has("shield", now):
        return [{"e": "push", "a": pusher.uid, "b": best.uid, "blocked": 1}]
    impulse = phys.push_impulse * (1.7 if pusher.has("push_boost", now) else 1.0)
    if best.has("anti_push", now):
        impulse *= 0.35
    best.vx += dx / d * impulse
    best.vz += dz / d * impulse
    best.vy = max(best.vy, 3.5)
    best.grounded = False
    pusher.stats.pushes_landed += 1
    return [{"e": "push", "a": pusher.uid, "b": best.uid}]
