"""Authoritative Color Worlds match simulation (pure Python, no I/O, deterministic given a seed + inputs)."""
from __future__ import annotations

import math
import random
from dataclasses import asdict, dataclass

from games.color_worlds.abilities.registry import ABILITIES, roll_ability, use_ability
from games.color_worlds.config import (DEFAULT_TUNING, DT, FALL_KILL_Y, MAX_PLAYERS, MIN_PLAYERS, TOTAL_STAGES,
                                      Tuning, build_stage)
from games.color_worlds.engine.arena import FALLEN, SOLID, WARNING, Arena
from games.color_worlds.engine.combat import try_push
from games.color_worlds.engine.physics import is_dead, separate_players, step_player
from games.color_worlds.engine.state import PlayerState
from games.color_worlds.mechanics import MECHANICS
from games.color_worlds.stages.challenges import CHALLENGES
from games.color_worlds.worlds.registry import get_world

PHASES = ("countdown", "stage_intro", "scramble", "select", "resolve", "intermission", "finished")
ANIM_CODE = {"idle": 0, "walk": 1, "run": 2, "jump": 3, "fall": 4, "frozen": 5, "win": 6}
EFFECT_BITS = {"speed": 1, "shield": 2, "invisible": 4, "double_jump": 8, "push_boost": 16, "anti_push": 32,
               "slowmo": 64, "mega_jump": 128, "lucky": 256, "second_chance": 512, "frozen": 1024, "dashing": 2048}
FOREVER = 1e12


def arena_size_for(player_count: int) -> int:
    return max(6, min(12, math.ceil(math.sqrt(player_count)) + 4))


@dataclass
class PlayerResult:
    uid: int
    placement: int
    won: bool
    left: bool
    stages_survived: int
    rounds_survived: int
    challenges_completed: int
    pushes_landed: int


class Match:
    def __init__(self, players: list[tuple[int, str, dict]], seed: int, tuning: Tuning = DEFAULT_TUNING,
                 start_stage: int = 1):
        if not MIN_PLAYERS <= len(players) <= MAX_PLAYERS:
            raise ValueError(f"player count must be {MIN_PLAYERS}..{MAX_PLAYERS}")
        self.seed, self.tuning = seed, tuning
        self.rng = random.Random(seed)
        self.players: dict[int, PlayerState] = {u: PlayerState(uid=u, name=n, character=c) for u, n, c in players}
        self.initial_count = len(self.players)
        self.grid_n = arena_size_for(self.initial_count)
        self.now = 0.0
        self.phase = "countdown"
        self.phase_end = tuning.lobby_countdown
        self.stage_no = start_stage - 1
        self.stage = None
        self.world = None
        self.arena = Arena(self.grid_n)
        self.mechanics: list = []
        self.challenge = None
        self.round_no = 0
        self.round_counter = 0          # global, increases every round; used for elimination ordering
        self.target = -1
        self.target_revealed = False
        self.fall_at: float | None = None
        self.next_rotate = 0.0
        self.events: list[dict] = []
        self.finished = False
        self.end_reason: str | None = None
        self.winners: list[int] = []
        self._tick = 0
        self.last_stage_event: dict | None = None
        self._spawn_players()
        self.emit({"e": "countdown", "t": tuning.lobby_countdown, "n": self.grid_n})

    # ---------- small helpers ----------
    @property
    def phys(self):
        return self.world.physics if self.world else get_world(0).physics

    def emit(self, ev: dict) -> None:
        self.events.append(ev)

    def drain_events(self) -> list[dict]:
        ev, self.events = self.events, []
        return ev

    def alive(self) -> list[PlayerState]:
        return [p for p in self.players.values() if p.alive]

    def stage_end_time(self, now: float) -> float:
        return FOREVER

    def _spawn_players(self) -> None:
        total = self.grid_n * self.grid_n
        tiles = self.rng.sample(range(total), len(self.players))
        a = Arena(self.grid_n)
        for p, idx in zip(self.players.values(), tiles):
            p.x, p.z = a.tile_center(idx, 0.0)
            p.facing = self.rng.uniform(-math.pi, math.pi)

    # ---------- player input (always validated; never trusted) ----------
    def set_input(self, uid: int, mx: float, mz: float, run: bool, seq: int = 0) -> None:
        p = self.players.get(uid)
        if p is None or not p.alive:
            return
        if not (math.isfinite(mx) and math.isfinite(mz)):
            return
        mag = math.hypot(mx, mz)
        if mag > 1.0:
            mx, mz = mx / mag, mz / mag
        p.input.mx, p.input.mz, p.input.run = mx, mz, bool(run)
        p.input.seq = seq

    def press(self, uid: int, action: str) -> None:
        p = self.players.get(uid)
        if p is None or not p.alive or self.phase in ("countdown", "finished"):
            return
        if action == "jump":
            p.jump_pressed = True
        elif action == "push":
            p.push_pressed = True
        elif action == "ability":
            p.ability_pressed = True

    def disconnect(self, uid: int) -> None:
        p = self.players.get(uid)
        if p and p.connected:
            p.connected, p.disconnected_at = False, self.now
            p.input.mx = p.input.mz = 0.0
            self.emit({"e": "disconnected", "u": uid})

    def reconnect(self, uid: int) -> bool:
        p = self.players.get(uid)
        if p is None or p.left:
            return False
        p.connected, p.disconnected_at = True, None
        self.emit({"e": "reconnected", "u": uid})
        return True

    def leave(self, uid: int) -> None:
        p = self.players.get(uid)
        if p is None or p.left:
            return
        p.left, p.connected = True, False
        if p.alive:
            p.alive = False
            p.elimination_group = self.round_counter - 0.5
            self.emit({"e": "left", "u": uid})
        self._check_abandon()

    def _check_abandon(self) -> None:
        if self.finished or self.phase == "countdown":
            return
        live = [p for p in self.alive() if not p.left]
        if len(live) <= 1 and self.initial_count >= 2:
            self._finish("last_standing" if live else "abandoned", [p.uid for p in live])

    # ---------- main loop ----------
    def update(self, dt: float = DT) -> None:
        if self.finished:
            return
        self.now += dt
        self._tick += 1
        self._expire_disconnected()
        self._phase_logic()
        if self.finished:
            return
        self._simulate(dt)

    def _expire_disconnected(self) -> None:
        for p in list(self.players.values()):
            if not p.connected and not p.left and p.disconnected_at is not None \
                    and self.now - p.disconnected_at > self.tuning.disconnect_grace:
                self.leave(p.uid)

    def _phase_logic(self) -> None:
        now = self.now
        if self.phase == "countdown" and now >= self.phase_end:
            self._start_stage(max(1, self.stage_no + 1))
        elif self.phase == "stage_intro" and now >= self.phase_end:
            self._start_round()
        elif self.phase == "scramble":
            if now >= self.phase_end:
                self._reveal()
        elif self.phase == "select":
            self._rotate_colors(now)
            if now >= self.phase_end:
                self._start_resolve()
        elif self.phase == "resolve":
            if self.fall_at is not None and now >= self.fall_at:
                self._drop_floor()
            if now >= self.phase_end:
                self._end_round()
        elif self.phase == "intermission" and now >= self.phase_end:
            self._start_stage(self.stage_no + 1)

    # ---------- stage / round flow ----------
    def _start_stage(self, number: int) -> None:
        self.stage_no = number
        self.stage = build_stage(number)
        self.world = get_world(self.stage.world_index)
        self.arena = Arena(self.grid_n)
        self.round_no = 0
        for p in self.players.values():
            p.challenge_done, p.challenge_progress = False, 0
            p.effects.pop("lucky", None)
        self.mechanics = [MECHANICS[m](self, self.stage, self.rng) for m in self.world.mechanics]
        self.challenge = CHALLENGES[self.stage.challenge](self, self.stage, self.rng)
        self.phase, self.phase_end = "stage_intro", self.now + self.tuning.stage_intro
        self.last_stage_event = {"e": "stage", "n": number, "total": TOTAL_STAGES, "world": self.world.id,
                   "theme": self.world.theme, "grid": self.grid_n, "colors": self.stage.colors,
                   "rounds": self.stage.rounds, "select_time": self.stage.select_time,
                   "mech": [m.describe() for m in self.mechanics], "challenge": self.challenge.describe(),
                   "phys": {"friction": self.phys.friction}}
        self.emit(self.last_stage_event)

    def _start_round(self) -> None:
        self.round_no += 1
        self.round_counter += 1
        a = self.arena
        a.state = [SOLID] * (a.n * a.n)
        c = self.stage.colors
        layout = [i % c for i in range(a.n * a.n)]
        self.rng.shuffle(layout)
        self.target = self.rng.randrange(c)
        need = max(2, math.ceil(len(self.alive()) / 3))
        have = layout.count(self.target)
        if have < need:
            others = [i for i, v in enumerate(layout) if v != self.target]
            self.rng.shuffle(others)
            for i in others[: need - have]:
                layout[i] = self.target
        a.colors = layout
        self.target_revealed = False
        self.fall_at = None
        self.phase, self.phase_end = "scramble", self.now + self.tuning.scramble_time
        self.next_rotate = float("inf")
        self.emit({"e": "round", "n": self.round_no, "of": self.stage.rounds, "tiles": list(layout)})
        if self.challenge:
            self.challenge.on_round_start(self.now)

    def _reveal(self) -> None:
        self.target_revealed = True
        self.phase, self.phase_end = "select", self.now + self.stage.select_time
        self.emit({"e": "reveal", "c": self.target, "t": self.stage.select_time})
        if self.stage.number >= 7:
            self.next_rotate = self.now + self._rotate_interval()
        if self.challenge:
            self.challenge.on_select_start(self.now)

    def _rotate_interval(self) -> float:
        return self.stage.shuffle_interval * 3.6

    def _rotate_colors(self, now: float) -> None:
        """From stage 7 the floor colours slide along the rows during the select phase (conveyor style)."""
        if now < self.next_rotate:
            return
        a = self.arena
        for j in range(a.n):
            row = a.colors[j * a.n:(j + 1) * a.n]
            row = row[-1:] + row[:-1] if j % 2 == 0 else row[1:] + row[:1]
            a.colors[j * a.n:(j + 1) * a.n] = row
        self.next_rotate = now + self._rotate_interval()
        self.emit({"e": "tiles", "tiles": list(a.colors)})

    def _start_resolve(self) -> None:
        a = self.arena
        for i, col in enumerate(a.colors):
            if col != self.target:
                a.state[i] = WARNING
        self.phase, self.phase_end = "resolve", self.now + self.tuning.resolve_time
        self.fall_at = self.now + self.tuning.warning_time
        self._alive_at_resolve = {p.uid for p in self.alive()}
        self.emit({"e": "warning", "tiles": [i for i, s in enumerate(a.state) if s == WARNING]})
        if self.challenge:
            self.challenge.on_resolve_start(self.now)

    def _drop_floor(self) -> None:
        a = self.arena
        fallen = [i for i, s in enumerate(a.state) if s == WARNING]
        for i in fallen:
            a.state[i] = FALLEN
        self.fall_at = None
        self.emit({"e": "fall", "tiles": fallen})

    def _end_round(self) -> None:
        for p in self.alive():
            if not p.grounded and p.y < -0.5:
                self._eliminate(p, "fell")
        survivors = self.alive()
        for p in survivors:
            p.stats.rounds_survived += 1
            if self.challenge:
                for uid in self.challenge.on_round_survived(p):
                    self.grant_challenge(self.players[uid])
        self.emit({"e": "round_end", "alive": len(survivors)})
        if not survivors:
            # everyone fell in the same round: they all tie for first
            tied = [uid for uid in getattr(self, "_alive_at_resolve", set()) if not self.players[uid].left]
            return self._finish("all_fell", tied)
        if len(survivors) == 1 and self.initial_count >= 2:
            return self._finish("last_standing", [survivors[0].uid])
        if self.round_no >= self.stage.rounds:
            for p in survivors:
                p.stats.stages_survived += 1
            if self.stage_no >= TOTAL_STAGES:
                return self._finish("completed", [p.uid for p in survivors])
            self.phase, self.phase_end = "intermission", self.now + self.tuning.intermission
            self.emit({"e": "stage_end", "n": self.stage_no, "alive": len(survivors)})
        else:
            self._start_round()

    def _eliminate(self, p: PlayerState, reason: str) -> None:
        p.alive = False
        p.elimination_group = self.round_counter
        p.vx = p.vz = 0.0
        self.emit({"e": "out", "u": p.uid, "why": reason, "left": len(self.alive())})

    def _finish(self, reason: str, winner_ids: list[int]) -> None:
        self.finished, self.end_reason, self.winners = True, reason, list(winner_ids)
        self.phase = "finished"
        for uid in self.winners:
            p = self.players[uid]
            p.elimination_group = FOREVER
            p.anim = "win"
        for p in self.players.values():
            if p.uid not in self.winners and p.elimination_group is None:
                p.elimination_group = self.round_counter - 0.5
                p.alive = False
        self.emit({"e": "finished", "reason": reason, "winners": self.winners})

    # ---------- challenge rewards ----------
    def grant_challenge(self, p: PlayerState) -> None:
        if p.challenge_done or not p.alive:
            return
        p.challenge_done = True
        p.stats.challenges_completed += 1
        gave = None
        if p.held_ability is None and self.tuning.challenge_enabled:
            gave = roll_ability(self.rng)
            p.held_ability = gave
        self.emit({"e": "challenge", "u": p.uid, "ability": gave})

    # ---------- simulation tick ----------
    def _simulate(self, dt: float) -> None:
        if self.phase == "countdown":
            return
        now = self.now
        for p in self.alive():
            if p.push_pressed:
                for ev in try_push(p, self.players, self.phys, now):
                    self.emit(ev)
            if p.ability_pressed:
                use_ability(self, p, now, self.tuning.ability_duration_scale)
            p.push_pressed = p.ability_pressed = False
        for m in self.mechanics:
            m.update(dt, now)
        for p in self.alive():
            for ev in step_player(p, self.arena, self.phys, dt, now):
                self.emit(ev)
        separate_players(list(self.players.values()))
        if self.challenge and self.phase in ("scramble", "select", "resolve"):
            for uid in self.challenge.update(dt, now):
                self.grant_challenge(self.players[uid])
        for p in self.alive():
            if is_dead(p):
                self._eliminate(p, "fell")

    # ---------- views for the network layer ----------
    def target_for(self, uid: int) -> int:
        p = self.players.get(uid)
        if self.target_revealed:
            return self.target
        if p and p.has("lucky", self.now) and self.phase == "scramble":
            return self.target
        return -1

    def snapshot(self) -> dict:
        now = self.now
        rows = []
        for p in self.players.values():
            fx = 0
            for name, bit in EFFECT_BITS.items():
                if p.has(name, now):
                    fx |= bit
            rows.append([p.uid, round(p.x, 2), round(p.y, 2), round(p.z, 2), round(p.facing, 2),
                         ANIM_CODE.get(p.anim, 0), fx, int(p.alive), int(p.connected)])
        snap = {"ph": self.phase, "tm": round(max(0.0, self.phase_end - now), 2), "mt": round(now, 2),
                "st": self.stage_no, "rd": self.round_no, "tg": self.target if self.target_revealed else -1,
                "al": len(self.alive()), "p": rows}
        extra: dict = {}
        for m in self.mechanics:
            s = m.snapshot(now)
            if s:
                extra.update(s)
        if self.challenge:
            s = self.challenge.snapshot(now)
            if s:
                extra.update(s)
        if extra:
            snap["x"] = extra
        return snap

    def context(self) -> list[dict]:
        """Events that rebuild the client's view of the current stage (used when a player reconnects)."""
        evs: list[dict] = []
        if self.last_stage_event:
            evs.append({**self.last_stage_event, "silent": 1})
        if self.round_no > 0:
            evs.append({"e": "round", "n": self.round_no, "of": self.stage.rounds, "tiles": list(self.arena.colors), "silent": 1})
            evs.append({"e": "states", "state": list(self.arena.state)})
        if self.target_revealed:
            evs.append({"e": "reveal", "c": self.target, "t": max(0.0, self.phase_end - self.now), "silent": 1})
        if self.challenge:
            evs.extend(self.challenge.replay_events())
        return evs

    def player_view(self, uid: int) -> dict:
        p = self.players.get(uid)
        if p is None:
            return {}
        v = {"ab": p.held_ability, "pcd": round(max(0.0, p.push_ready_at - self.now), 2),
             "cp": p.challenge_progress, "cd": int(p.challenge_done)}
        lucky = self.target_for(uid)
        if lucky >= 0 and not self.target_revealed:
            v["tg"] = lucky
        return v

    # ---------- results ----------
    def results(self) -> list[PlayerResult]:
        order = sorted(self.players.values(), key=lambda p: -(p.elimination_group if p.elimination_group is not None else FOREVER))
        out, placement_of_group = [], {}
        for rank, p in enumerate(order, start=1):
            g = p.elimination_group if p.elimination_group is not None else FOREVER
            placement_of_group.setdefault(g, rank)
            out.append(PlayerResult(p.uid, placement_of_group[g], p.uid in self.winners, p.left,
                                    p.stats.stages_survived, p.stats.rounds_survived,
                                    p.stats.challenges_completed, p.stats.pushes_landed))
        return out

    # ---------- crash recovery ----------
    def to_persist(self) -> dict:
        return {"seed": self.seed, "stage_no": self.stage_no, "round_counter": self.round_counter,
                "players": [{"uid": p.uid, "name": p.name, "character": p.character, "x": p.x, "z": p.z,
                             "alive": p.alive, "left": p.left, "held": p.held_ability,
                             "group": p.elimination_group, "stats": asdict(p.stats)} for p in self.players.values()]}

    @classmethod
    def from_persist(cls, data: dict, tuning: Tuning = DEFAULT_TUNING) -> "Match":
        """Rebuild a running match after a server restart. Play resumes at the start of the saved stage;
        all players start disconnected and get the normal grace period to reconnect."""
        plist = data["players"]
        if len([p for p in plist if p["alive"] and not p["left"]]) < 1:
            raise ValueError("nothing to restore")
        base = [(p["uid"], p["name"], p["character"]) for p in plist]
        m = cls(base, data["seed"] + data["stage_no"] * 7919, tuning, start_stage=max(1, data["stage_no"]))
        m.round_counter = data["round_counter"]
        for pd in plist:
            p = m.players[pd["uid"]]
            p.x, p.z, p.alive, p.left, p.held_ability = pd["x"], pd["z"], pd["alive"], pd["left"], pd["held"]
            p.elimination_group = pd["group"]
            for k, v in pd["stats"].items():
                setattr(p.stats, k, v)
            p.connected, p.disconnected_at = False, 0.0
        m.phase_end = m.now + 0.5
        m.emit({"e": "restored"})
        return m
