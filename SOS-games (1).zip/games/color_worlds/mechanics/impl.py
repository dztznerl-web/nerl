from __future__ import annotations

import math

from games.color_worlds.engine.arena import SOLID
from games.color_worlds.mechanics.base import Mechanic, knock


class MovingPlatforms(Mechanic):
    """Alternate rows slide sideways. Players standing on a moving row are carried with it."""
    id = "moving_platforms"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        a = match.arena
        a.row_amp = stage.platform_amplitude
        a.moving_rows = {j: (0.0 if (j // 1) % 2 == 0 else math.pi) for j in range(1, a.n, 2)} if a.row_amp > 0 else {}
        self._prev = 0.0

    def update(self, dt, now):
        a = self.match.arena
        if not a.moving_rows:
            return
        for p in self.match.players.values():
            if not (p.alive and p.grounded):
                continue
            j = math.floor(p.z / a.ts + a.n / 2)
            if j in a.moving_rows:
                p.x += a.row_offset(j, now) - a.row_offset(j, now - dt)

    def describe(self):
        a = self.match.arena
        return {"id": self.id, "amp": a.row_amp, "freq": a.row_freq, "rows": a.moving_rows}


class Wind(Mechanic):
    id = "wind"

    def update(self, dt, now):
        strength = 1.5 + 4.5 * self.stage.hazard_level
        ang = now * 0.25
        gust = 0.6 + 0.4 * math.sin(now * 1.3)
        ax, az = math.cos(ang) * strength * gust, math.sin(ang) * strength * gust
        for p in self.match.players.values():
            if p.alive and not p.has("shield", now):
                k = 1.0 if not p.grounded else 0.45
                if p.has("anti_push", now):
                    k *= 0.4
                p.vx += ax * k * dt
                p.vz += az * k * dt

    def describe(self):
        return {"id": self.id}

    def snapshot(self, now):
        ang = now * 0.25
        return {"wind": [round(math.cos(ang), 2), round(math.sin(ang), 2)]}


class Sweepers(Mechanic):
    """Rotating bars around the arena centre that knock players away."""
    id = "sweepers"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        self.count = 1 + int(stage.hazard_level * 2.2)
        self.speed = 0.7 + 1.1 * stage.hazard_level
        self.length = match.arena.half_extent * 0.95

    def angle(self, k: int, now: float) -> float:
        return now * self.speed + k * (2 * math.pi / self.count)

    def update(self, dt, now):
        if self.match.phase not in ("select", "resolve", "scramble"):
            return
        for k in range(self.count):
            ang = self.angle(k, now)
            ux, uz = math.cos(ang), math.sin(ang)
            for p in self.match.players.values():
                if not p.alive or p.y > 1.0:
                    continue
                t = max(0.0, min(self.length, p.x * ux + p.z * uz))
                cx, cz = ux * t, uz * t
                if math.hypot(p.x - cx, p.z - cz) < 0.75:
                    tx, tz = -uz, ux  # direction of travel of the bar
                    if knock(p, tx + (p.x - cx) * 0.5, tz + (p.z - cz) * 0.5, 9.0, 4.0, now):
                        self.match.emit({"e": "hit", "u": p.uid, "src": "sweeper"})

    def describe(self):
        return {"id": self.id, "count": self.count, "speed": self.speed, "length": self.length}


class Geysers(Mechanic):
    id = "geysers"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        self.next_at = 2.0
        self.active: list[dict] = []   # {x,z,warn_until,erupt_until}
        self.interval = max(1.2, 3.5 - 2.2 * stage.hazard_level)

    def update(self, dt, now):
        if self.match.phase in ("select", "scramble") and now >= self.next_at:
            solid = self.match.arena.solid_indices()
            if solid:
                x, z = self.match.arena.tile_center(self.rng.choice(solid), now)
                self.active.append({"x": x, "z": z, "warn": now + 1.0, "end": now + 1.5})
            self.next_at = now + self.interval
        for g in list(self.active):
            if now >= g["end"]:
                self.active.remove(g)
                continue
            if now >= g["warn"]:
                for p in self.match.players.values():
                    if p.alive and p.y < 1.5 and math.hypot(p.x - g["x"], p.z - g["z"]) < 1.7:
                        if knock(p, p.x - g["x"], p.z - g["z"], 6.0, 13.0, now, 1.0):
                            self.match.emit({"e": "hit", "u": p.uid, "src": "geyser"})

    def snapshot(self, now):
        return {"geysers": [[round(g["x"], 2), round(g["z"], 2), int(now >= g["warn"])] for g in self.active]} if self.active else None


class Traps(Mechanic):
    """Temple floor traps: a tile telegraphs for 1.2s then fires for 0.6s, launching whoever stands on it."""
    id = "traps"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        total = match.arena.n * match.arena.n
        k = max(2, int(total * (0.04 + 0.1 * stage.hazard_level)))
        self.tiles = rng.sample(range(total), k)
        self.phase = {t: rng.random() * 4.0 for t in self.tiles}
        self.period = 4.0

    def _state(self, t: int, now: float) -> str:
        x = (now + self.phase[t]) % self.period
        return "warn" if 0.0 <= x < 1.2 else "fire" if x < 1.8 else "idle"

    def update(self, dt, now):
        if self.match.phase not in ("select", "resolve", "scramble"):
            return
        a = self.match.arena
        for p in self.match.players.values():
            if not (p.alive and p.grounded):
                continue
            idx = a.tile_index_at(p.x, p.z, now)
            if idx in self.phase and self._state(idx, now) == "fire":
                cx, cz = a.tile_center(idx, now)
                if knock(p, p.x - cx + 0.01, p.z - cz, 7.0, 9.0, now, 1.2):
                    self.match.emit({"e": "hit", "u": p.uid, "src": "trap"})

    def describe(self):
        return {"id": self.id, "tiles": self.tiles}

    def snapshot(self, now):
        return {"traps": [[t, 1 if self._state(t, now) == "fire" else 0] for t in self.tiles
                          if self._state(t, now) != "idle"]}


class BouncePads(Mechanic):
    id = "bounce_pads"

    def __init__(self, match, stage, rng):
        super().__init__(match, stage, rng)
        total = match.arena.n * match.arena.n
        match.arena.pads = set(rng.sample(range(total), max(2, int(total * 0.08))))

    def describe(self):
        return {"id": self.id, "pads": sorted(self.match.arena.pads)}
