from games.color_worlds.mechanics.impl import BouncePads, Geysers, MovingPlatforms, Sweepers, Traps, Wind

MECHANICS = {m.id: m for m in (MovingPlatforms, Wind, Sweepers, Geysers, Traps, BouncePads)}
