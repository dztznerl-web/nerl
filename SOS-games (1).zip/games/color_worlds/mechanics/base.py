from __future__ import annotations

import math


def knock(p, dx: float, dz: float, force: float, hop: float, now: float, cooldown: float = 0.8) -> bool:
    """Apply a hazard knockback respecting shield / anti-push and a per-player cooldown."""
    if p.hit_cooldown_until > now or p.has("shield", now):
        return False
    d = math.hypot(dx, dz) or 1.0
    scale = 0.35 if p.has("anti_push", now) else 1.0
    p.vx += dx / d * force * scale
    p.vz += dz / d * force * scale
    p.vy = max(p.vy, hop)
    p.grounded = False
    p.hit_cooldown_until = now + cooldown
    return True


class Mechanic:
    id = "base"

    def __init__(self, match, stage, rng):
        self.match, self.stage, self.rng = match, stage, rng

    def update(self, dt: float, now: float) -> None: ...

    def describe(self) -> dict:
        return {"id": self.id}

    def snapshot(self, now: float) -> dict | None:
        return None
