"""XP / coins / levels / achievements / daily missions. Everything is computed on the server from the
authoritative match result. Grants are idempotent: a unique key per (match, player) makes double payout impossible."""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import date
from typing import Protocol

from games.color_worlds.config import TOTAL_STAGES


def xp_threshold(level: int) -> int:
    """Total XP needed to *reach* `level` (level 1 = 0)."""
    return 0 if level <= 1 else int(100 * (level - 1) ** 1.5)


def level_for_xp(xp: int) -> int:
    level = 1
    while xp >= xp_threshold(level + 1):
        level += 1
    return level


@dataclass(frozen=True)
class Reward:
    xp: int
    coins: int


def compute_reward(*, placement: int, won: bool, left: bool, stages_survived: int, rounds_survived: int,
                   challenges: int, player_count: int, win_streak_before: int, scale: float = 1.0) -> Reward:
    """Fair scaling: tiny lobbies pay less so two friends cannot farm rewards."""
    if player_count < 2:
        return Reward(0, 0)
    size_factor = 0.4 + 0.6 * min(player_count, 10) / 10
    xp = 10 + rounds_survived * 3 + stages_survived * 8 + challenges * 15
    coins = rounds_survived + stages_survived * 3 + challenges * 5
    if left:
        xp, coins = xp // 4, coins // 4
    elif won:
        streak = min(win_streak_before + 1, 5)
        xp += 100 + (streak - 1) * 20
        coins += 50 + (streak - 1) * 10
    elif placement <= 3:
        xp += 25
        coins += 10
    return Reward(int(xp * size_factor * scale), int(coins * size_factor * scale))


@dataclass
class Stats:
    xp: int = 0
    coins: int = 0
    level: int = 1
    games_played: int = 0
    wins: int = 0
    win_streak: int = 0
    best_win_streak: int = 0
    challenges_completed: int = 0
    pushes_landed: int = 0
    best_stage: int = 0


ACHIEVEMENTS = {
    "first_win": ("اول فوز", lambda s: s.wins >= 1),
    "win_streak_3": ("ثلاث انتصارات متتالية", lambda s: s.best_win_streak >= 3),
    "veteran": ("لعبت 10 جولات", lambda s: s.games_played >= 10),
    "challenger": ("اكملت 25 تحدي", lambda s: s.challenges_completed >= 25),
    "pusher": ("دفعت 50 لاعب", lambda s: s.pushes_landed >= 50),
    "level_10": ("وصلت مستوى 10", lambda s: s.level >= 10),
    "marathon": ("اكملت كل المراحل", lambda s: s.best_stage >= TOTAL_STAGES),
}

MISSION_POOL = {
    "play_3": ("العب 3 جولات", 3, "games_played", Reward(40, 20)),
    "win_1": ("افز بجولة", 1, "wins", Reward(80, 40)),
    "challenges_3": ("اكمل 3 تحديات", 3, "challenges", Reward(50, 25)),
    "stages_10": ("اجتز 10 مراحل", 10, "stages", Reward(60, 30)),
    "pushes_5": ("ادفع 5 لاعبين", 5, "pushes", Reward(40, 20)),
}


def daily_mission_ids(day: date, count: int = 3) -> list[str]:
    rng = random.Random(day.toordinal())
    return rng.sample(sorted(MISSION_POOL), count)


@dataclass
class MatchOutcome:
    uid: int
    placement: int
    won: bool
    left: bool
    stages_survived: int
    rounds_survived: int
    challenges_completed: int
    pushes_landed: int
    best_stage_reached: int = 0


@dataclass
class AwardSummary:
    uid: int
    xp: int
    coins: int
    level: int
    leveled_up: bool
    achievements: list[str] = field(default_factory=list)
    missions_completed: list[str] = field(default_factory=list)
    duplicate: bool = False


class ProgressStore(Protocol):
    async def get_stats(self, uid: int) -> Stats: ...
    async def save_stats(self, uid: int, stats: Stats) -> None: ...
    async def record_reward(self, uid: int, key: str, source: str, xp: int, coins: int, meta: dict) -> bool: ...
    async def unlock_achievement(self, uid: int, achievement_id: str) -> bool: ...
    async def mission_progress(self, uid: int, day: date) -> dict[str, dict]: ...
    async def set_mission(self, uid: int, day: date, mission_id: str, progress: int, target: int,
                          completed: bool) -> None: ...
    async def claim_mission(self, uid: int, day: date, mission_id: str) -> bool: ...
    async def list_achievements(self, uid: int) -> list[str]: ...
    async def leaderboard(self, by: str, limit: int) -> list[dict]: ...


class InMemoryProgressStore:
    def __init__(self) -> None:
        self.stats: dict[int, Stats] = {}
        self.rewards: dict[str, tuple] = {}
        self.achievements: set[tuple[int, str]] = set()
        self.missions: dict[tuple[int, date, str], dict] = {}

    async def get_stats(self, uid): return Stats(**vars(self.stats.get(uid, Stats())))
    async def save_stats(self, uid, stats): self.stats[uid] = Stats(**vars(stats))

    async def record_reward(self, uid, key, source, xp, coins, meta):
        if key in self.rewards:
            return False
        self.rewards[key] = (uid, source, xp, coins, meta)
        return True

    async def unlock_achievement(self, uid, achievement_id):
        if (uid, achievement_id) in self.achievements:
            return False
        self.achievements.add((uid, achievement_id))
        return True

    async def mission_progress(self, uid, day):
        return {k[2]: dict(v) for k, v in self.missions.items() if k[0] == uid and k[1] == day}

    async def set_mission(self, uid, day, mission_id, progress, target, completed):
        cur = self.missions.get((uid, day, mission_id), {"claimed": False})
        self.missions[(uid, day, mission_id)] = {"progress": progress, "target": target, "completed": completed,
                                                 "claimed": cur["claimed"]}

    async def list_achievements(self, uid):
        return sorted(a for u, a in self.achievements if u == uid)

    async def leaderboard(self, by, limit):
        key = "wins" if by == "wins" else "xp"
        rows = sorted(self.stats.items(), key=lambda kv: -getattr(kv[1], key))[:limit]
        return [{"rank": i + 1, "uid": u, "name": str(u), "xp": s.xp, "level": s.level, "wins": s.wins} for i, (u, s) in enumerate(rows)]

    async def claim_mission(self, uid, day, mission_id):
        m = self.missions.get((uid, day, mission_id))
        if not m or not m["completed"] or m["claimed"]:
            return False
        m["claimed"] = True
        return True


class ProgressService:
    def __init__(self, store: ProgressStore, reward_scale: float = 1.0):
        self.store, self.reward_scale = store, reward_scale

    async def award_match(self, session_id: str, outcomes: list[MatchOutcome], day: date | None = None) -> list[AwardSummary]:
        day = day or date.today()
        n = len(outcomes)
        summaries = []
        for o in outcomes:
            key = f"game:{session_id}:{o.uid}"
            stats = await self.store.get_stats(o.uid)
            reward = compute_reward(placement=o.placement, won=o.won, left=o.left, stages_survived=o.stages_survived,
                                    rounds_survived=o.rounds_survived, challenges=o.challenges_completed,
                                    player_count=n, win_streak_before=stats.win_streak, scale=self.reward_scale)
            fresh = await self.store.record_reward(o.uid, key, "game_result", reward.xp, reward.coins,
                                                   {"placement": o.placement})
            if not fresh:   # already paid for this match: do nothing (idempotent)
                summaries.append(AwardSummary(o.uid, 0, 0, stats.level, False, duplicate=True))
                continue
            old_level = stats.level
            stats.xp += reward.xp
            stats.coins += reward.coins
            stats.games_played += 1
            stats.challenges_completed += o.challenges_completed
            stats.pushes_landed += o.pushes_landed
            stats.best_stage = max(stats.best_stage, o.best_stage_reached)
            if o.won and not o.left:
                stats.wins += 1
                stats.win_streak += 1
                stats.best_win_streak = max(stats.best_win_streak, stats.win_streak)
            else:
                stats.win_streak = 0
            stats.level = level_for_xp(stats.xp)
            new_ach = []
            for ach_id, (_, pred) in ACHIEVEMENTS.items():
                if pred(stats) and await self.store.unlock_achievement(o.uid, ach_id):
                    new_ach.append(ach_id)
            done = await self._update_missions(o, day)
            await self.store.save_stats(o.uid, stats)
            summaries.append(AwardSummary(o.uid, reward.xp, reward.coins, stats.level, stats.level > old_level,
                                          new_ach, done))
        return summaries

    async def _update_missions(self, o: MatchOutcome, day: date) -> list[str]:
        deltas = {"games_played": 1, "wins": int(o.won and not o.left), "challenges": o.challenges_completed,
                  "stages": o.stages_survived, "pushes": o.pushes_landed}
        current = await self.store.mission_progress(o.uid, day)
        completed_now = []
        for mid in daily_mission_ids(day):
            title, target, metric, _ = MISSION_POOL[mid]
            prev = current.get(mid, {"progress": 0, "completed": False})
            if prev["completed"]:
                continue
            prog = min(target, prev["progress"] + deltas[metric])
            done = prog >= target
            await self.store.set_mission(o.uid, day, mid, prog, target, done)
            if done:
                completed_now.append(mid)
        return completed_now

    async def claim_mission(self, uid: int, mission_id: str, day: date | None = None) -> Reward | None:
        day = day or date.today()
        if mission_id not in daily_mission_ids(day):
            return None
        if not await self.store.claim_mission(uid, day, mission_id):
            return None
        reward = MISSION_POOL[mission_id][3]
        if not await self.store.record_reward(uid, f"mission:{day.isoformat()}:{mission_id}:{uid}", "mission",
                                              reward.xp, reward.coins, {}):
            return None
        stats = await self.store.get_stats(uid)
        stats.xp += reward.xp
        stats.coins += reward.coins
        stats.level = level_for_xp(stats.xp)
        await self.store.save_stats(uid, stats)
        return reward
