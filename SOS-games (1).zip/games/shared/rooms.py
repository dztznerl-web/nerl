"""Room lifecycle shared by every game. All mutations run under one asyncio lock, so simultaneous
join/leave requests can never push a room past max_players."""
from __future__ import annotations

import asyncio
import secrets
import time
from dataclasses import dataclass, field

CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no ambiguous 0/O/1/I


class RoomError(Exception):
    def __init__(self, code: str, message: str = ""):
        super().__init__(message or code)
        self.code = code


@dataclass
class RoomPlayer:
    uid: int
    name: str
    character: dict
    ready: bool = False


@dataclass
class Room:
    code: str
    game_type: str
    host_uid: int
    chat_id: int | None
    max_players: int
    min_players: int
    status: str = "waiting"            # waiting | running | finished | stopped
    players: dict[int, RoomPlayer] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    members: set[int] = field(default_factory=set)   # everyone who joined (kept for reconnect while running)

    def view(self) -> dict:
        return {"code": self.code, "game": self.game_type, "host": self.host_uid, "status": self.status,
                "count": len(self.players), "max": self.max_players, "min": self.min_players,
                "chat_id": self.chat_id,
                "players": [{"uid": p.uid, "name": p.name, "character": p.character, "ready": p.ready}
                            for p in self.players.values()]}


class RoomManager:
    def __init__(self, max_rooms: int = 500):
        self.rooms: dict[str, Room] = {}
        self.user_room: dict[int, str] = {}
        self.max_rooms = max_rooms
        self._lock = asyncio.Lock()

    def _new_code(self) -> str:
        for _ in range(50):
            code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(5))
            if code not in self.rooms:
                return code
        raise RoomError("no_code", "could not allocate room code")

    async def create(self, host_uid: int, name: str, character: dict, game_type: str, *, chat_id: int | None,
                     max_players: int, min_players: int) -> Room:
        async with self._lock:
            if len(self.rooms) >= self.max_rooms:
                raise RoomError("server_busy", "too many rooms")
            await self._leave_locked(host_uid)
            room = Room(self._new_code(), game_type, host_uid, chat_id, max_players, min_players)
            room.players[host_uid] = RoomPlayer(host_uid, name, character)
            room.members.add(host_uid)
            self.rooms[room.code] = room
            self.user_room[host_uid] = room.code
            return room

    def get(self, code: str) -> Room:
        room = self.rooms.get(code.upper())
        if room is None:
            raise RoomError("not_found", "room not found")
        return room

    async def join(self, code: str, uid: int, name: str, character: dict) -> Room:
        async with self._lock:
            room = self.get(code)
            if uid in room.players:
                return room                                     # idempotent re-join
            if room.status == "running" and uid in room.members:
                return room                                     # reconnect handled by the hub
            if room.status != "waiting":
                raise RoomError("closed", "game already started")
            if len(room.players) >= room.max_players:
                raise RoomError("full", "room is full")
            await self._leave_locked(uid)
            room.players[uid] = RoomPlayer(uid, name, character)
            room.members.add(uid)
            self.user_room[uid] = room.code
            return room

    async def leave(self, uid: int) -> Room | None:
        async with self._lock:
            return await self._leave_locked(uid)

    async def _leave_locked(self, uid: int) -> Room | None:
        code = self.user_room.pop(uid, None)
        room = self.rooms.get(code) if code else None
        if room is None:
            return None
        room.players.pop(uid, None)
        if room.status == "waiting":
            room.members.discard(uid)
            if not room.players:
                del self.rooms[room.code]
                return room
            if uid == room.host_uid:
                room.host_uid = next(iter(room.players))        # transfer host to the longest-waiting player
        return room

    async def set_ready(self, uid: int, ready: bool) -> Room:
        async with self._lock:
            room = self._room_of(uid)
            if room.status != "waiting":
                raise RoomError("closed", "game already started")
            room.players[uid].ready = ready
            return room

    async def set_character(self, uid: int, character: dict) -> Room:
        async with self._lock:
            room = self._room_of(uid)
            room.players[uid].character = character
            return room

    def _room_of(self, uid: int) -> Room:
        code = self.user_room.get(uid)
        if code is None or code not in self.rooms:
            raise RoomError("not_in_room", "you are not in a room")
        return self.rooms[code]

    async def start(self, uid: int) -> tuple[Room, list[tuple[int, str, dict]]]:
        """Host starts with however many players are present (>= min). Waiting for more is never forced."""
        async with self._lock:
            room = self._room_of(uid)
            if room.host_uid != uid:
                raise RoomError("not_host", "only the room creator can start")
            if room.status != "waiting":
                raise RoomError("closed", "game already started")
            if len(room.players) < room.min_players:
                raise RoomError("not_enough", f"need at least {room.min_players} players")
            room.status = "running"
            return room, [(p.uid, p.name, p.character) for p in room.players.values()]

    async def close(self, code: str, status: str = "finished") -> None:
        async with self._lock:
            room = self.rooms.get(code)
            if room is None:
                return
            room.status = status
            for uid in list(room.players):
                if self.user_room.get(uid) == code:
                    del self.user_room[uid]
            del self.rooms[code]

    def list_open(self, game_type: str | None = None, chat_id: int | None = None) -> list[dict]:
        out = []
        for r in self.rooms.values():
            if r.status != "waiting":
                continue
            if game_type and r.game_type != game_type:
                continue
            if chat_id is not None and r.chat_id != chat_id:
                continue
            out.append(r.view())
        return out

    def rooms_for_chat(self, chat_id: str | int) -> list[Room]:
        return [r for r in self.rooms.values() if str(r.chat_id) == str(chat_id)]

    # --- persistence for restarts (waiting rooms only; running matches persist via Match.to_persist) ---
    def to_persist(self) -> list[dict]:
        return [{"code": r.code, "game": r.game_type, "host": r.host_uid, "chat_id": r.chat_id, "max": r.max_players,
                 "min": r.min_players, "status": r.status, "players": [
                     {"uid": p.uid, "name": p.name, "character": p.character, "ready": p.ready}
                     for p in r.players.values()]} for r in self.rooms.values()]

    def restore(self, data: list[dict]) -> None:
        for d in data:
            room = Room(d["code"], d["game"], d["host"], d["chat_id"], d["max"], d["min"], d["status"])
            for p in d["players"]:
                room.players[p["uid"]] = RoomPlayer(p["uid"], p["name"], p["character"], p["ready"])
                room.members.add(p["uid"])
                self.user_room[p["uid"]] = room.code
            self.rooms[room.code] = room
