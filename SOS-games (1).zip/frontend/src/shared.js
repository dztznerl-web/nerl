// Constants and formulas that MUST match the Python engine (games/color_worlds).
export const TILE = 3.0;
export const FX = { speed: 1, shield: 2, invisible: 4, double_jump: 8, push_boost: 16, anti_push: 32, slowmo: 64, mega_jump: 128, lucky: 256, second_chance: 512, frozen: 1024, dashing: 2048 };
export const ANIMS = ['idle', 'walk', 'run', 'jump', 'fall', 'frozen', 'win'];

export function rowOffset(amp, freq, phase, t) {
  return !amp || phase === undefined || phase === null ? 0 : amp * Math.sin(freq * t + phase);
}
export function sweeperAngle(k, count, speed, t) { return t * speed + k * (2 * Math.PI / count); }
export function tileCenter(idx, n, ts, offsetX = 0) {
  const j = Math.floor(idx / n), i = idx % n;
  return [(i - (n - 1) / 2) * ts + offsetX, (j - (n - 1) / 2) * ts];
}
export function lerp(a, b, t) { return a + (b - a) * t; }
export function lerpAngle(a, b, t) {
  const d = ((b - a + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
  return a + d * t;
}
export const CHAR_COLORS = ['#ff3b5c', '#2d9cff', '#2ecc71', '#ffd23f', '#b15cff', '#ff8a2b', '#19d3c5', '#ff6fcf', '#ffffff', '#8b5a2b', '#3a3a4a', '#a0e000'];
export const CHAR_OPTIONS = { body: 8, color: 12, hat: 6, face: 5 };
export const BODY_NAMES = ['كبسولة', 'فاصولية', 'مكعب', 'مخروط', 'طويل', 'كرة', 'ضخم', 'نحيف'];
export const HAT_NAMES = ['بدون', 'كاب', 'قبعة حفلة', 'تاج', 'هوائي', 'قرون'];
export const FACE_NAMES = ['سعيد', 'عيون كبيرة', 'نعسان', 'نظارة', 'شنب'];
export function hex(n) { return parseInt(String(n).replace('#', ''), 16); }
