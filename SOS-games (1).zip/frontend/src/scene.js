// Three.js scene: arena floor, world decorations, lighting, and per-world hazards visuals.
import { TILE, rowOffset, tileCenter, sweeperAngle } from './shared.js';
import { themeFor } from './worlds.js';

export class Scene {
  constructor(THREE, canvas) {
    this.THREE = THREE;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
    this.camTarget = new THREE.Vector3();
    this.tiles = []; this.decor = new THREE.Group(); this.hazards = new THREE.Group(); this.platforms = new THREE.Group();
    this.scene.add(this.decor, this.hazards, this.platforms);
    this.n = 0; this.grid = 0; this.world = null; this.clock = 0;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  setWorld(worldId, grid) {
    const THREE = this.THREE;
    const th = themeFor(worldId);
    this.world = th;
    this.scene.background = new THREE.Color(th.sky);
    this.scene.fog = new THREE.Fog(th.fog, 30, 90);
    while (this.decor.children.length) this.decor.remove(this.decor.children[0]);
    this.decorateWorld(th);
    this.lights && this.lights.forEach(l => this.scene.remove(l));
    const amb = new THREE.AmbientLight(0xffffff, 0.55);
    const sun = new THREE.DirectionalLight(th.light, 0.9);
    sun.position.set(12, 22, 8); sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, { left: -20, right: 20, top: 20, bottom: -20, far: 80 });
    this.lights = [amb, sun];
    this.lights.forEach(l => this.scene.add(l));
    this.buildGrid(grid);
  }
  decorateWorld(th) {
    const THREE = this.THREE;
    const add = (m) => this.decor.add(m);
    const glow = new THREE.MeshStandardMaterial({ color: th.glow, emissive: th.glow, emissiveIntensity: 0.8 });
    const base = new THREE.MeshStandardMaterial({ color: th.ground, roughness: 0.8 });
    const far = 40;
    // skyline / islands / pillars depending on world kind
    const count = th.kind === 'neon' || th.kind === 'cyber' ? 26 : th.kind === 'sky' ? 14 : 18;
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2, r = 28 + (i % 3) * 6;
      let mesh;
      if (th.kind === 'neon' || th.kind === 'cyber') {
        const h = 6 + ((i * 37) % 17);
        mesh = new THREE.Mesh(new THREE.BoxGeometry(2.5, h, 2.5), i % 2 ? base : glow);
        mesh.position.set(Math.cos(a) * r, h / 2 - 2, Math.sin(a) * r);
      } else if (th.kind === 'sky') {
        mesh = new THREE.Mesh(new THREE.DodecahedronGeometry(3 + (i % 4), 0), base);
        mesh.position.set(Math.cos(a) * r, -4 + (i % 5) * 2, Math.sin(a) * r);
      } else if (th.kind === 'lava') {
        mesh = new THREE.Mesh(new THREE.ConeGeometry(2.4, 6 + (i % 4), 6), base);
        mesh.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
      } else if (th.kind === 'ice') {
        mesh = new THREE.Mesh(new THREE.ConeGeometry(1.6, 4 + (i % 3) * 2, 5), new THREE.MeshStandardMaterial({ color: 0xeaf8ff, transparent: true, opacity: 0.85 }));
        mesh.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
      } else if (th.kind === 'candy') {
        mesh = new THREE.Mesh(new THREE.SphereGeometry(2 + (i % 3), 14, 10), new THREE.MeshStandardMaterial({ color: [0xff7ac6, 0xfff29e, 0x9ef0ff][i % 3] }));
        mesh.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
      } else {
        mesh = new THREE.Mesh(new THREE.CylinderGeometry(1, 1.2, 8, 8), base);
        mesh.position.set(Math.cos(a) * r, 2, Math.sin(a) * r);
      }
      mesh.castShadow = true;
      add(mesh);
    }
    const sky = new THREE.Mesh(new THREE.SphereGeometry(far * 3, 16, 12), new THREE.MeshBasicMaterial({ color: th.sky, side: THREE.BackSide }));
    add(sky);
  }
  buildGrid(n) {
    const THREE = this.THREE;
    for (const t of this.tiles) this.scene.remove(t.mesh);
    this.tiles = [];
    this.n = n; this.grid = n;
    const geo = new THREE.BoxGeometry(TILE * 0.96, 0.4, TILE * 0.96);
    for (let i = 0; i < n * n; i++) {
      const mat = new THREE.MeshStandardMaterial({ color: 0x444466, emissive: 0x000000, roughness: 0.4, metalness: 0.1 });
      const mesh = new THREE.Mesh(geo, mat);
      const [x, z] = tileCenter(i, n, TILE);
      mesh.position.set(x, -0.2, z); mesh.receiveShadow = true;
      this.scene.add(mesh);
      this.tiles.push({ mesh, mat, base: 0, row: Math.floor(i / n), state: 0, color: -1, x, z, pop: 0 });
    }
    this.camera.position.set(0, 16, 14);
    this.camTarget.set(0, 0, 0);
  }
  applyTiles(colors, palette) {
    colors.forEach((c, i) => {
      const t = this.tiles[i];
      if (!t) return;
      if (t.color !== c) {
        t.color = c;
        t.mat.color.setHex(parseInt(palette[c].slice(1), 16));
        t.mat.emissive.setHex(parseInt(palette[c].slice(1), 16));
        t.mat.emissiveIntensity = 0.12;
        t.pop = 1;
      }
    });
  }
  dropTiles(indices) {
    for (const i of indices) {
      const t = this.tiles[i];
      if (!t) continue;
      t.state = 2;
      t.warn = false;
      t.mesh.visible = false;
    }
  }
  setWarnings(indices) {
    const set = new Set(indices);
    this.tiles.forEach((t, i) => { t.warn = set.has(i); });
  }
  update(dt, t, snap) {
    const sizeOffset = (rowIdx) => rowOffset(this.platAmp, this.platFreq, this.rowPhase && this.rowPhase[rowIdx], t);
    for (const tile of this.tiles) {
      if (tile.pop > 0) {
        tile.pop = Math.max(0, tile.pop - dt * 3);
        const s = 1 + Math.sin(tile.pop * Math.PI) * 0.08;
        tile.mesh.scale.set(s, 1, s);
      }
      if (tile.warn) {
        const blink = Math.sin(t * 16) > 0;
        tile.mat.emissiveIntensity = blink ? 0.9 : 0.05;
      } else if (tile.state === 0) {
        tile.mat.emissiveIntensity = Math.max(0.05, tile.mat.emissiveIntensity * 0.97);
      }
      if (this.platAmp) {
        tile.mesh.position.x = tile.x + sizeOffset(tile.row);
      }
    }
  }
  setMovingRows(amp, freq, rows) {
    this.platAmp = amp; this.platFreq = freq;
    this.rowPhase = rows || {};
  }
  setCameraFollow(x, y, z) {
    this.camTarget.lerp({ x, y: y + 1, z }, 0.12);
    this.camera.position.lerp({ x: this.camTarget.x * 0.5, y: 16 + y * 0.3, z: this.camTarget.z + 14 }, 0.06);
    this.camera.lookAt(this.camTarget);
  }
  render() { this.renderer.render(this.scene, this.camera); }
  add(obj) { this.scene.add(obj); return obj; }
  remove(obj) { this.scene.remove(obj); }
}
