// Particles, shockwaves and floating text. Pure visual, driven by server events.
export class Effects {
  constructor(THREE, scene) {
    this.THREE = THREE; this.scene = scene; this.items = [];
  }
  burst(x, y, z, color, count = 18, speed = 4, life = 0.6) {
    const THREE = this.THREE;
    const geo = new THREE.SphereGeometry(0.08, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color });
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(geo, mat.clone());
      m.position.set(x, y, z);
      const a = Math.random() * Math.PI * 2, u = Math.random() * 2 - 1;
      const v = new THREE.Vector3(Math.cos(a) * Math.sqrt(1 - u * u), Math.abs(u) + 0.3, Math.sin(a) * Math.sqrt(1 - u * u)).multiplyScalar(speed * (0.5 + Math.random()));
      this.scene.add(m);
      this.items.push({ m, v, life, max: life, g: 14, kill: true });
    }
  }
  ring(x, y, z, color, radius = 3, life = 0.5) {
    const THREE = this.THREE;
    const m = new THREE.Mesh(new THREE.RingGeometry(0.2, 0.3, 32), new THREE.MeshBasicMaterial({ color, transparent: true, side: THREE.DoubleSide }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, y + 0.05, z);
    this.scene.add(m);
    this.items.push({ m, life, max: life, grow: radius, ring: true });
  }
  floatText(text, x, y, z, color = '#fff') {
    const el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = `position:fixed;pointer-events:none;font:900 18px system-ui;color:${color};text-shadow:0 2px 6px #000;transition:transform .9s ease-out,opacity .9s;transform:translate(-50%,-50%)`;
    document.body.appendChild(el);
    this.items.push({ dom: el, x, y, z, life: 0.9, max: 0.9 });
  }
  update(dt, project) {
    for (const it of this.items) {
      it.life -= dt;
      if (it.dom) {
        const p = project ? project(it.x, it.y, it.z) : null;
        if (p) { it.dom.style.left = p.x + 'px'; it.dom.style.top = p.y + 'px'; }
        it.dom.style.opacity = String(Math.max(0, it.life / it.max));
        it.y += dt * 1.2;
        if (it.life <= 0) it.dom.remove();
        continue;
      }
      if (it.ring) {
        const k = 1 - it.life / it.max;
        it.m.scale.setScalar(0.5 + k * it.grow);
        it.m.material.opacity = 1 - k;
        if (it.life <= 0) this.scene.remove(it.m);
        continue;
      }
      it.m.position.addScaledVector(it.v, dt);
      it.v.y -= it.g * dt;
      it.m.material.opacity = Math.max(0, it.life / it.max);
      it.m.material.transparent = true;
      it.m.scale.setScalar(Math.max(0.2, it.life / it.max));
      if (it.life <= 0) this.scene.remove(it.m);
    }
    this.items = this.items.filter(it => it.life > 0);
  }
  clear() {
    for (const it of this.items) {
      if (it.dom) it.dom.remove();
      else if (it.m) this.scene.remove(it.m);
    }
    this.items = [];
  }
}
