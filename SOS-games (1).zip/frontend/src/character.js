// Procedural stylised characters (no third-party assets). Built from primitives + simple animation.
import { CHAR_COLORS, hex } from './shared.js';

export function buildCharacter(THREE, spec = {}) {
  const color = hex(CHAR_COLORS[spec.color ?? 0] || CHAR_COLORS[0]);
  const root = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.45, metalness: 0.05 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xffe0bd, roughness: 0.7 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x1b1b2b, roughness: 0.6 });

  const bodyGeo = [
    () => (typeof THREE.CapsuleGeometry === 'function' ? new THREE.CapsuleGeometry(0.42, 0.5, 6, 12) : new THREE.CylinderGeometry(0.42, 0.42, 1.0, 16)),
    () => new THREE.SphereGeometry(0.5, 20, 16),
    () => new THREE.BoxGeometry(0.8, 0.9, 0.8),
    () => new THREE.ConeGeometry(0.5, 1.0, 16),
    () => new THREE.CylinderGeometry(0.35, 0.42, 1.2, 16),
    () => new THREE.SphereGeometry(0.55, 24, 18),
    () => new THREE.DodecahedronGeometry(0.55, 0),
    () => new THREE.CylinderGeometry(0.3, 0.3, 1.1, 14),
  ][spec.body ?? 0]();
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0.75; body.castShadow = true;
  root.add(body);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.34, 18, 14), skin);
  head.position.y = 1.55; head.castShadow = true;
  root.add(head);

  const eyeGeo = new THREE.SphereGeometry(0.06, 8, 8);
  const faceKind = spec.face ?? 0;
  for (const sx of [-1, 1]) {
    const e = new THREE.Mesh(eyeGeo, dark);
    e.position.set(sx * 0.12, 1.6, 0.3);
    if (faceKind === 1) e.scale.setScalar(1.8);
    root.add(e);
  }
  if (faceKind === 3) {
    const g = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.015, 6, 14), dark);
    g.position.set(0, 1.6, 0.32); root.add(g);
  }
  if (faceKind === 4) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.04, 0.04), dark);
    m.position.set(0, 1.45, 0.33); root.add(m);
  }

  const hat = spec.hat ?? 0;
  if (hat === 1) {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.08, 16), dark);
    b.position.y = 1.82; root.add(b);
  } else if (hat === 2) {
    const c = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.5, 12), new THREE.MeshStandardMaterial({ color: 0xffd23f }));
    c.position.y = 2.1; root.add(c);
  } else if (hat === 3) {
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.14, 16), new THREE.MeshStandardMaterial({ color: 0xffd23f, metalness: 0.6, roughness: 0.3 }));
    t.position.y = 1.88; root.add(t);
  } else if (hat === 4) {
    const s = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.6, 6), dark);
    s.position.set(0.18, 2.0, 0); root.add(s);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshStandardMaterial({ color: 0xff3b5c, emissive: 0xff3b5c }));
    ball.position.set(0.18, 2.3, 0); root.add(ball);
  } else if (hat === 5) {
    for (const sx of [-1, 1]) {
      const h = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.35, 8), new THREE.MeshStandardMaterial({ color: 0xfff1c1 }));
      h.position.set(sx * 0.2, 1.95, 0); h.rotation.z = sx * -0.4; root.add(h);
    }
  }

  const limbs = {};
  for (const [name, x, y] of [['armL', -0.5, 0.95], ['armR', 0.5, 0.95], ['legL', -0.2, 0.25], ['legR', 0.2, 0.25]]) {
    const pivot = new THREE.Group();
    pivot.position.set(x, y, 0);
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.5, 8), name.startsWith('arm') ? bodyMat : dark);
    m.position.y = -0.25;
    pivot.add(m);
    root.add(pivot);
    limbs[name] = pivot;
  }

  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.5, 20), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.25 }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.02; root.add(shadow);

  const api = { root, body, limbs, phase: 0, anim: 'idle', bobT: 0 };
  api.setAnim = (name) => { api.anim = name; };
  api.update = (dt, speed, anim) => {
    api.phase += dt * (anim === 'run' ? 14 : 8);
    const sw = anim === 'walk' || anim === 'run' ? Math.sin(api.phase) * (anim === 'run' ? 0.9 : 0.5) : 0;
    limbs.armL.rotation.x = sw; limbs.armR.rotation.x = -sw;
    limbs.legL.rotation.x = -sw; limbs.legR.rotation.x = sw;
    if (anim === 'jump') { limbs.armL.rotation.x = limbs.armR.rotation.x = -2.2; limbs.legL.rotation.x = limbs.legR.rotation.x = 0.4; }
    if (anim === 'fall') { limbs.armL.rotation.x = limbs.armR.rotation.x = -2.8; limbs.legL.rotation.x = 0.6; limbs.legR.rotation.x = -0.6; }
    if (anim === 'frozen') { limbs.armL.rotation.x = limbs.armR.rotation.x = 0; }
    if (anim === 'win') { api.bobT += dt * 9; limbs.armL.rotation.x = limbs.armR.rotation.x = -2.6 + Math.sin(api.bobT) * 0.3; }
    const idleBob = anim === 'idle' ? Math.sin(api.phase * 0.6) * 0.03 : 0;
    body.scale.set(1 + idleBob, 1 - idleBob, 1 + idleBob);
    return sw;
  };
  return api;
}

export function setTint(THREE, character, hexColor) {
  character.body.material.color.setHex(hex(hexColor));
}
