// App controller: screens, lobby, match rendering, reconnection and results.
import { authenticate, api, Net } from './net.js';
import { sfx, unlock, setEnabled, isEnabled } from './audio.js';
import { Scene } from './scene.js';
import { Effects } from './effects.js';
import { Input } from './input.js';
import { buildCharacter } from './character.js';
import { CHAR_COLORS, CHAR_OPTIONS, BODY_NAMES, HAT_NAMES, FACE_NAMES, FX, ANIMS } from './shared.js';
import { $, show, toast, modal, el, vibrate } from './ui.js';

const tg = window.Telegram && window.Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor && tg.setHeaderColor('#0b0b1e'); } catch { /* ignore */ } }

const S = {
  token: null, me: null, cfg: null, net: null, char: { body: 0, color: 0, hat: 0, face: 0 },
  room: null, match: null, playerObjs: new Map(), lastSnap: null, snapTime: 0, myUid: null, bannerTimer: null,
  sound: true, pendingMatch: null, lastRoomView: null,
};
let THREE = null, gameScene = null, fx = null, input = null, rafId = 0, lastT = 0;

// ------------------------------------------------------------------ boot
async function boot() {
  try {
    setStatus('جاري الاتصال...');
    const auth = await authenticate();
    S.token = auth.token; S.me = auth.user; S.startChat = auth.chat_id;
    S.cfg = await fetch('/api/config').then(r => r.json());
    await refreshHome();
    S.net = new Net(S.token, { message: onMessage, status: onConn });
    S.net.connect();
    $('s-loading') && $('s-loading').classList.remove('active');
    show('home');
    if (typeof THREE === 'undefined') THREE = window.THREE;
  } catch (e) {
    setStatus(e.message || 'خطأ غير متوقع');
  }
}
function setStatus(text) { $('loading-text').textContent = text; show('loading'); }

async function refreshHome() {
  const d = await api('/api/me', S.token);
  S.me = d.user; S.profile = d;
  $('home-name').textContent = S.me.name;
  $('home-avatar').textContent = (S.me.name || '؟').slice(0, 1);
  $('home-level').textContent = 'مستوى ' + d.stats.level;
  const span = Math.max(1, d.next_level_xp - d.level_xp);
  $('home-xp').style.width = Math.min(100, ((d.stats.xp - d.level_xp) / span) * 100) + '%';
  $('home-xptext').textContent = d.stats.xp + ' / ' + d.next_level_xp + ' XP';
  $('home-coins').textContent = d.stats.coins;
}

// ------------------------------------------------------------------ connection
function onConn(up) {
  $('hud-conn').classList.toggle('hidden', up);
}

function onMessage(m) {
  switch (m.t) {
    case 'hello':
      S.myUid = m.uid; S.maintenance = m.maintenance; S.roomsOpen = m.rooms || [];
      if (m.room) { S.room = m.room; showWaiting(); }
      break;
    case 'room':
      S.room = m.room; if (!S.match) showWaiting();
      break;
    case 'rooms':
      S.roomsOpen = m.rooms; if ($('s-rooms').classList.contains('active')) renderRooms();
      break;
    case 'start':
      startMatch(m);
      break;
    case 'snap':
      onSnap(m);
      break;
    case 'ev':
      onEvents(m.e);
      break;
    case 'result':
      showResult(m);
      break;
    case 'stopped':
      endMatchUI(); toast(m.reason === 'admin' ? 'أوقف المطور اللعبة' : 'توقفت اللعبة', 2200);
      show('home'); refreshHome();
      break;
    case 'left':
      S.room = null; break;
    case 'error':
      handleError(m);
      break;
  }
}

function handleError(m) {
  const msgs = { full: 'الغرفة ممتلئة', closed: 'اللعبة بدأت بالفعل', not_host: 'منشئ الغرفة فقط يبدأ اللعبة', not_enough: 'تحتاج لاعبين على الأقل',
    not_found: 'الغرفة غير موجودة', wrong_chat: 'هذي الغرفة تابعة لقروب ثاني', maintenance: 'الخدمة في وضع الصيانة',
    banned: 'حسابك محظور', rate_limited: 'خفف شوي', replaced: 'فتحت اللعبة من جهاز ثاني', left: 'خرجت من المباراة' };
  const text = msgs[m.code] || m.msg || 'حصل خطأ';
  if (m.code === 'replaced' || m.code === 'banned') { modal(text).then(() => { try { tg && tg.close(); } catch { /* ignore */ } }); return; }
  toast(text, 2200, 'err');
}

// ------------------------------------------------------------------ rooms & lobby
function renderRooms() {
  const list = $('rooms-list'); list.textContent = '';
  const rooms = S.roomsOpen || [];
  $('rooms-empty').classList.toggle('hidden', rooms.length > 0);
  for (const r of rooms) {
    list.append(el('div', { class: 'item' },
      el('div', { class: 'grow' }, el('b', {}, 'غرفة ' + r.code), el('div', { class: 'tag' }, r.count + '/' + r.max + ' لاعب')),
      el('button', { class: 'ghost', onclick: () => join(r.code) }, 'انضم')));
  }
}

function join(code) {
  S.net.send({ t: 'join', code, character: S.char });
}

function showWaiting() {
  show('waiting');
  renderWaiting();
}
function renderWaiting() {
  const r = S.room; if (!r) return;
  const me = r.players.find(p => p.uid === S.myUid);
  const isHost = r.host === S.myUid;
  $('wait-code').textContent = r.code;
  $('wait-count').textContent = r.count;
  $('wait-max').textContent = r.max;
  const box = $('wait-players'); box.textContent = '';
  for (const p of r.players) {
    const c = CHAR_COLORS[p.character && p.character.color || 0] || '#888';
    box.append(el('div', { class: 'pl' + (p.ready ? ' ready' : '') + (p.uid === r.host ? ' host' : '') },
      el('div', { class: 'dot', style: `background:${c}` }), p.name));
  }
  $('wait-ready-box').classList.toggle('hidden', !isHost);
  $('btn-ready').textContent = me && me.ready ? 'جاهز ✔ (الغي)' : 'جاهز';
  $('btn-ready').classList.toggle('on', !!(me && me.ready));
  const canStart = r.count >= r.min;
  $('btn-start').disabled = !canStart;
  $('wait-ready-msg').textContent = canStart
    ? `الغرفة جاهزة · عدد اللاعبين ${r.count}/${r.max}`
    : `تحتاج ${r.min - r.count} لاعب آخر على الأقل للبدء`;
  $('wait-hint').textContent = isHost ? 'تقدر تبدأ الحين أو تنتظر المزيد من اللاعبين' : 'بانتظار منشئ الغرفة يبدأ اللعبة';
}

// ------------------------------------------------------------------ match
async function ensureThree() {
  if (!THREE) THREE = window.THREE;
  if (!THREE) throw new Error('three.js لم يتحمّل');
}

async function startMatch(m) {
  await ensureThree();
  S.match = { start: m, grid: m.grid };
  S.myUid = m.you;
  show('game');
  if (!gameScene) {
    gameScene = new Scene(THREE, $('gl'));
    fx = new Effects(THREE, gameScene.scene);
    input = new Input($('stick'), $('knob'), { 'b-jump': 'jump', 'b-push': 'push', 'b-ability': 'ability', 'b-run': 'run' }, onPress);
    lastT = performance.now();
    loop();
  }
  S.playerObjs.forEach(o => gameScene.remove(o.root));
  S.playerObjs.clear();
  for (const p of m.players) {
    const obj = buildCharacter(THREE, p.character);
    gameScene.add(obj.root);
    S.playerObjs.set(p.uid, obj);
  }
  gameScene.setWorld(m.snap.world || 'neon_city', m.grid);
  applySnapshot(m.snap, true);
  for (const ev of (m.replay || [])) onEvent(ev, true);
  $('hud-conn').classList.add('hidden');
  $('hud-banner-text').textContent = 'استعد...';
  unlock();
  $('b-ability').classList.add('hidden');
}

function onPress(action) {
  if (!S.match) return;
  if (action === 'run') return;
  unlock();
  S.net.send({ t: action });
  if (action === 'jump') sfx.jump();
  if (action === 'push') { vibrate(12); }
}

function onSnap(m) {
  if (!S.match) return;
  S.lastSnap = m; S.snapTime = performance.now();
  applySnapshot(m, false);
}

function applySnapshot(s, initial) {
  if (!gameScene) return;
  const stageNo = S.stage || 1;
  $('hud-round').textContent = s.rd || 1;
  $('hud-alive').textContent = s.al;
  if (s.tg !== undefined && s.tg >= 0 && S.palette) {
    $('hud-swatch').classList.add('on');
    $('hud-swatch').style.background = S.palette[s.tg];
    $('hud-swatch').style.color = S.palette[s.tg];
  }
  const ph = s.ph;
  const timer = $('hud-timer');
  timer.textContent = Math.ceil(s.tm || 0);
  timer.classList.toggle('urgent', (s.tm || 0) <= 2 && ph === 'select');
  const ban = $('hud-banner-text');
  const labels = { countdown: 'استعد!', stage_intro: 'المرحلة ' + stageNo, scramble: 'انتظر الإشارة...', select: 'اختار اللون!', resolve: 'الأرض تنهار...', intermission: 'استراحة', finished: 'انتهت' };
  if (!S.targetLabelSet || s.tg === -1 || ph !== 'select') ban.textContent = labels[ph] || '';
  for (const row of s.p || []) {
    const [uid, x, y, z, facing, anim, fxBits, alive, connected] = row;
    const obj = S.playerObjs.get(uid);
    if (!obj) continue;
    obj.root.visible = !!alive && !(fxBits & FX.invisible && uid !== S.myUid);
    obj.root.position.set(x, y, z);
    obj.root.rotation.y = facing;
    obj.serverAnim = ANIMS[anim] || 'idle';
    obj.fx = fxBits;
    obj.connected = !!connected;
    obj.root.traverse(c => { if (c.material && c.material.transparent !== undefined && c.isMesh) { c.material.transparent = true; c.material.opacity = connected ? 1 : 0.4; } });
  }
  if (s.x) {
    if (s.x.geysers) S.geysers = s.x.geysers;
    if (s.x.bars) S.bars = s.x.bars;
    if (s.x.wind) S.wind = s.x.wind;
  }
  const mv = s.me || {};
  S.myHeld = !!mv.ab;
  S.heldAbility = mv.ab || null;
  $('b-ability').classList.toggle('hidden', !S.myHeld);
  if (S.myHeld) $('b-ability-name').textContent = abilityName(S.heldAbility);
  const cd = Math.max(0, mv.pcd || 0);
  $('push-cd').style.height = Math.min(100, (cd / 1.5) * 100) + '%';
  if (mv.cp !== undefined) $('hud-ch-bar').style.width = Math.min(100, (mv.cp / Math.max(1, S.challengeTarget || 1)) * 100) + '%';
}

function onEvents(list) { for (const e of list) onEvent(e, false); }

function onEvent(e, silent) {
  switch (e.e) {
    case 'countdown': if (!silent) sfx.countdown(); break;
    case 'stage': {
      S.stage = e.n; S.palette = palettePlaceholder(e.colors); S.challengeTarget = e.challenge && e.challenge.target;
      S.targetLabelSet = false;
      $('hud-world').textContent = e.theme ? (e.world || '') : '';
      $('hud-stage').textContent = e.n;
      $('hud-challenge').classList.remove('hidden');
      $('hud-ch-text').textContent = challengeText(e.challenge);
      $('hud-ch-bar').style.width = '0%';
      if (!silent) { sfx.go(); toast('المرحلة ' + e.n + ' · ' + e.world, 2000); }
      break;
    }
    case 'round': {
      if (gameScene) gameScene.applyTiles(e.tiles, S.palette || defaultPalette(16));
      $('hud-round').textContent = e.n;
      break;
    }
    case 'reveal':
      if (!silent) { sfx.reveal(); vibrate(40); toast('اللون: ' + colorName(e.c), 1200); }
      break;
    case 'warning':
      if (!silent) sfx.warn();
      if (gameScene) gameScene.setWarnings(e.tiles);
      break;
    case 'fall':
      if (gameScene) { gameScene.setWarnings([]); gameScene.dropTiles(e.tiles); }
      if (!silent) sfx.fall();
      break;
    case 'out': {
      const obj = S.playerObjs.get(e.u);
      if (obj && !silent) { fx.burst(obj.root.position.x, 0.5, obj.root.position.z, 0xff3b5c, 22, 5); sfx.out(); }
      if (e.u === S.myUid && !silent) toast('طلعت من الجولة', 2000, 'err');
      break;
    }
    case 'push': {
      const a = S.playerObjs.get(e.a), b = S.playerObjs.get(e.b);
      if (!silent && a) sfx.push();
      if (b && !silent) fx.burst(b.root.position.x, 1, b.root.position.z, 0xffd23f, 12, 4);
      break;
    }
    case 'hit':
      if (!silent) { sfx.hit(); const o = S.playerObjs.get(e.u); if (o) fx.burst(o.root.position.x, 1, o.root.position.z, 0xff8a2b, 10, 3); }
      break;
    case 'jump': if (!silent) sfx.jump(); break;
    case 'land': if (!silent) sfx.land(); break;
    case 'pad': if (!silent) { sfx.pad(); const o = S.playerObjs.get(e.u); if (o) fx.ring(o.root.position.x, 0, o.root.position.z, 0x2ecc71, 3); } break;
    case 'pickup': if (!silent) sfx.pickup(); break;
    case 'cleared': if (!silent) sfx.pickup(); break;
    case 'challenge':
      if (!silent) {
        sfx.power();
        const o = S.playerObjs.get(e.u);
        if (o) fx.ring(o.root.position.x, 0, o.root.position.z, 0xffd23f, 6, 0.8);
        if (e.u === S.myUid) { vibrate([30, 40, 30]); toast(e.ability ? 'حصلت قدرة: ' + abilityName(e.ability) : 'أكملت التحدي!', 2000); S.myHeld = !!e.ability; S.heldAbility = e.ability; }
      }
      break;
    case 'ability':
      if (!silent) { sfx.ability(); const o = S.playerObjs.get(e.u); if (o) fx.ring(o.root.position.x, 0.2, o.root.position.z, 0x00e5ff, 4); }
      if (e.u === S.myUid) { S.myHeld = false; S.heldAbility = null; $('b-ability').classList.add('hidden'); }
      break;
    case 'freeze': if (!silent) sfx.hit(); break;
    case 'teleport': {
      const o = S.playerObjs.get(e.u);
      if (o) { o.root.position.set(e.x, o.root.position.y, e.z); if (!silent) fx.burst(e.x, 1, e.z, 0x00e5ff, 16, 3); }
      break;
    }
    case 'dash': if (!silent) sfx.push(); break;
    case 'stage_end': if (!silent) toast('انتهت المرحلة ' + e.n, 2000); break;
    case 'finished': break;
    case 'left': case 'disconnected': case 'reconnected': case 'restored': break;
    case 'platforms': case 'zone': case 'items': case 'tiles': case 'states': break;
  }
  if (e.e === 'challenge') S.challengeDone = true;
}

function challengeText(c) {
  if (!c) return '';
  return {
    survive_rounds: 'اصمد ' + c.target + ' جولات',
    collect: 'اجمع ' + c.target + ' عناصر',
    reach_zone: 'ادخل المنطقة المضيئة',
    jump_count: 'اقفز فوق ' + c.target + ' حواجز',
    reach_platform: 'اصعد للمنصة المرتفعة',
  }[c.kind] || 'تحدي';
}
function abilityName(id) { return (S.cfg && S.cfg.abilities[id] && S.cfg.abilities[id].ar) || id; }
function colorName(i) { return (S.cfg && S.cfg.color_names[i]) || ''; }
function palettePlaceholder(n) { return defaultPalette(n); }
function defaultPalette(n) { return (S.cfg ? S.cfg.colors : ['#ff3b5c', '#2d9cff', '#2ecc71', '#ffd23f', '#b15cff', '#ff8a2b', '#19d3c5', '#ff6fcf']).slice(0, Math.max(3, n)); }

function endMatchUI() {
  S.match = null;
  if (gameScene) { fx.clear(); }
  S.playerObjs.forEach(o => gameScene && gameScene.remove(o.root));
  S.playerObjs.clear();
  $('hud-challenge').classList.add('hidden');
}

function showResult(m) {
  endMatchUI();
  const won = m.me.won;
  (won ? sfx.win : sfx.lose)();
  $('res-title').textContent = won ? '🏆 فزت!' : m.reason === 'abandoned' ? 'اللعبة انتهت' : 'انتهت الجولة';
  $('res-place').textContent = '#' + m.me.placement;
  const a = m.award;
  $('res-award').textContent = a ? `+${a.xp} XP · +${a.coins} 🪙` + (a.level_up ? ` · مستوى ${a.level}!` : '') + (a.achievements && a.achievements.length ? ' · إنجاز جديد!' : '') : 'لا مكافآت لهذي الجولة';
  const list = $('res-standings'); list.textContent = '';
  for (const s of m.standings.slice(0, 30)) {
    list.append(el('div', { class: 'item' }, el('b', { style: 'min-width:34px' }, '#' + s.placement), el('div', { class: 'grow' }, s.name), s.won ? el('span', {}, '🏆') : null));
  }
  show('result');
  S.lastResult = m;
  S.myHeld = false;
}

// ------------------------------------------------------------------ render loop
function loop(now) {
  rafId = requestAnimationFrame(loop);
  const t = (now || performance.now()) / 1000;
  const dt = Math.min(0.05, t - (lastT || t)); lastT = t;
  if (gameScene && S.match && S.lastSnap) {
    for (const [uid, obj] of S.playerObjs) {
      if (!obj.root.visible) continue;
      const anim = obj.fx & FX.frozen ? 'frozen' : (obj.serverAnim || 'idle');
      obj.update(dt, 0, anim);
    }
    gameScene.update(dt, t, S.lastSnap);
    const me = S.playerObjs.get(S.myUid);
    if (me) gameScene.setCameraFollow(me.root.position.x, me.root.position.y, me.root.position.z);
    if (input) {
      const mx = round(input.mx), mz = round(input.mz), run = !!input.run;
      if (mx !== S.lastMx || mz !== S.lastMz || run !== S.lastRun) {
        S.net.send({ t: 'in', mx, mz, run, seq: (S.seq = (S.seq || 0) + 1) });
        S.lastMx = mx; S.lastMz = mz; S.lastRun = run;
      }
    }
  }
  if (fx) fx.update(dt, project);
  if (gameScene) gameScene.render();
}
function round(v) { return Math.round(v * 100) / 100; }
function project(x, y, z) {
  if (!gameScene) return null;
  const v = new THREE.Vector3(x, y, z).project(gameScene.camera);
  return { x: (v.x + 1) / 2 * window.innerWidth, y: (-v.y + 1) / 2 * window.innerHeight };
}

// ------------------------------------------------------------------ navigation
function bindUI() {
  document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => { unlock(); show('home'); }));
  $('btn-play').onclick = () => { unlock(); sfx.click(); S.net.send({ t: 'rooms' }); show('rooms'); renderRooms(); };
  $('btn-refresh').onclick = () => { S.net.send({ t: 'rooms' }); };
  $('btn-create').onclick = () => { unlock(); S.net.send({ t: 'create', character: S.char }); };
  $('btn-join-code').onclick = () => { const c = $('join-code').value.trim(); if (c) join(c); };
  $('btn-ready').onclick = () => { const me = S.room && S.room.players.find(p => p.uid === S.myUid); S.net.send({ t: 'ready', v: !(me && me.ready) }); };
  $('btn-start').onclick = () => { unlock(); S.net.send({ t: 'start' }); };
  $('btn-wait').onclick = () => toast('انتظار المزيد من اللاعبين...', 1500);
  $('btn-leave').onclick = () => { S.net.send({ t: 'leave' }); S.room = null; show('home'); };
  $('btn-copy').onclick = () => { try { navigator.clipboard.writeText(S.room.code); toast('تم نسخ الكود', 1200); } catch { toast(S.room.code, 2500); } };
  $('btn-again').onclick = () => { show('rooms'); S.net.send({ t: 'rooms' }); renderRooms(); };
  $('btn-home').onclick = () => { show('home'); refreshHome(); };
  $('btn-character').onclick = () => openCharacter();
  $('char-save').onclick = () => { S.net.send({ t: 'character', character: S.char }); toast('تم الحفظ', 1200); show('home'); };
  $('btn-worlds').onclick = () => openWorlds();
  $('btn-board').onclick = () => openBoard('xp');
  $('board-xp').onclick = () => openBoard('xp');
  $('board-wins').onclick = () => openBoard('wins');
  $('btn-missions').onclick = () => openMissions();
  $('btn-history').onclick = () => openHistory();
  $('btn-sound').onclick = () => { S.sound = !S.sound; setEnabled(S.sound); $('sound-label').textContent = 'الصوت: ' + (S.sound ? 'يعمل' : 'مقفل'); };
  $('b-ability').onclick = () => { unlock(); S.net.send({ t: 'ability' }); };
}

function openCharacter() {
  show('character');
  const box = $('char-controls'); box.textContent = '';
  const rows = [['body', 'الشكل', CHAR_OPTIONS.body, BODY_NAMES], ['color', 'اللون', CHAR_OPTIONS.color, null], ['hat', 'القبعة', CHAR_OPTIONS.hat, HAT_NAMES], ['face', 'الوجه', CHAR_OPTIONS.face, FACE_NAMES]];
  for (const [key, label, max, names] of rows) {
    const val = el('div', { class: 'val' }, labelFor(key, S.char[key], names));
    const step = (d) => { S.char[key] = (S.char[key] + d + max) % max; val.textContent = labelFor(key, S.char[key], names); refreshPreview(); };
    box.append(el('div', { class: 'opt' }, el('b', {}, label), el('button', { onclick: () => step(-1) }, '‹'), val, el('button', { onclick: () => step(1) }, '›')));
  }
  refreshPreview();
}
function labelFor(key, v, names) { return key === 'color' ? (S.cfg ? S.cfg.color_names[v] : v) : (names ? names[v] : v); }
function refreshPreview() {
  const host = $('char-preview'); host.textContent = '';
  if (!THREE) THREE = window.THREE;
  if (!THREE) return;
  const r = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  const w = host.clientWidth || 300, h = host.clientHeight || 230;
  r.setSize(w, h); r.setPixelRatio(1); host.append(r.domElement);
  const sc = new THREE.Scene(); sc.add(new THREE.AmbientLight(0xffffff, 0.8));
  const dl = new THREE.DirectionalLight(0xffffff, 0.9); dl.position.set(3, 5, 4); sc.add(dl);
  const cam = new THREE.PerspectiveCamera(40, w / h, 0.1, 50); cam.position.set(0, 1.6, 5); cam.lookAt(0, 1.1, 0);
  const c = buildCharacter(THREE, S.char); sc.add(c.root);
  c.root.rotation.y = 0.4;
  r.render(sc, cam);
  r.dispose();
  c.root.traverse(o => { if (o.geometry) o.geometry.dispose(); });
}

async function openWorlds() {
  show('worlds');
  const list = $('worlds-list'); list.textContent = '';
  const cfg = S.cfg || await fetch('/api/config').then(r => r.json());
  for (const w of cfg.worlds) {
    const base = ['#2a2a6a', '#5a1a0a', '#6aaed0', '#3a7a3a', '#e055a0', '#00506a', '#8a6030'][cfg.worlds.indexOf(w)] || '#333';
    list.append(el('div', { class: 'world-card', style: `background:linear-gradient(135deg,${base},#000)` },
      el('h4', {}, w.name_ar + ' · ' + w.name_en), el('p', {}, '٣ مراحل · تحديات وفخاخ خاصة بالعالم')));
  }
}

async function openBoard(by) {
  show('board');
  $('board-xp').classList.toggle('on', by === 'xp');
  $('board-wins').classList.toggle('on', by === 'wins');
  const rows = await api('/api/leaderboard?by=' + by + '&limit=30', S.token);
  const list = $('board-list'); list.textContent = '';
  if (!rows.length) list.append(el('div', { class: 'muted center' }, 'ما فيه نتائج بعد'));
  for (const r of rows) list.append(el('div', { class: 'item' }, el('b', { style: 'min-width:34px' }, '#' + r.rank), el('div', { class: 'grow' }, r.name, el('div', { class: 'tag' }, 'مستوى ' + r.level)), el('span', {}, by === 'wins' ? r.wins + ' 🏆' : r.xp + ' XP')));
}

async function openMissions() {
  show('missions');
  const d = await api('/api/me', S.token);
  const cfg = S.cfg;
  const ml = $('missions-list'); ml.textContent = '';
  for (const m of d.missions) {
    const info = cfg.missions[m.id];
    const pct = Math.min(100, (m.progress / m.target) * 100);
    const btn = m.completed && !m.claimed ? el('button', { class: 'primary', onclick: () => claimMission(m.id) }, 'استلم') : el('span', { class: 'tag' }, m.claimed ? 'تم ✔' : m.progress + '/' + m.target);
    ml.append(el('div', { class: 'item' }, el('div', { class: 'grow' }, el('b', {}, info.title), el('div', { class: 'xpbar' }, el('div', { style: `width:${pct}%` })), el('div', { class: 'tag' }, '+' + info.xp + ' XP · +' + info.coins + ' 🪙')), btn));
  }
  const al = $('ach-list'); al.textContent = '';
  for (const [id, name] of Object.entries(cfg.achievements)) {
    const got = d.achievements.includes(id);
    al.append(el('div', { class: 'item', style: got ? '' : 'opacity:.45' }, el('span', {}, got ? '🏅' : '🔒'), el('div', { class: 'grow' }, name)));
  }
}
async function claimMission(id) {
  const r = await fetch(`/api/missions/${id}/claim`, { method: 'POST', headers: { Authorization: 'Bearer ' + S.token } });
  if (r.ok) { toast('استلمت المكافأة', 1500); await refreshHome(); openMissions(); } else toast('ما تقدر تستلمها الحين', 1600, 'err');
}

async function openHistory() {
  show('history');
  const rows = await api('/api/history', S.token);
  const list = $('history-list'); list.textContent = '';
  if (!rows.length) list.append(el('div', { class: 'muted center' }, 'ما لعبت بعد'));
  for (const r of rows) list.append(el('div', { class: 'item' }, el('b', { style: 'min-width:44px' }, '#' + r.placement), el('div', { class: 'grow' }, r.players + ' لاعب · مرحلة ' + r.stages, el('div', { class: 'tag' }, r.at ? new Date(r.at).toLocaleString('ar-SA') : '')), el('span', {}, '+' + r.xp + ' XP')));
}

// ------------------------------------------------------------------ start
bindUI();
boot();
