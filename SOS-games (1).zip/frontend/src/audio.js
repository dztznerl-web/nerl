// Synthesized sound effects (no audio files needed). Must be unlocked by a user gesture.
let ctx = null;
let enabled = true;

export function unlock() {
  if (!ctx) {
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { ctx = null; }
  }
  if (ctx && ctx.state === 'suspended') ctx.resume();
}
export function setEnabled(v) { enabled = v; }
export function isEnabled() { return enabled; }

function tone(freq, dur, type = 'sine', vol = 0.15, slide = 0, delay = 0) {
  if (!ctx || !enabled) return;
  const t0 = ctx.currentTime + delay;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t0 + dur);
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t0); o.stop(t0 + dur + 0.02);
}
function noise(dur, vol = 0.12, delay = 0) {
  if (!ctx || !enabled) return;
  const n = Math.floor(ctx.sampleRate * dur), buf = ctx.createBuffer(1, n, ctx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const s = ctx.createBufferSource(), g = ctx.createGain();
  s.buffer = buf; g.gain.value = vol; s.connect(g).connect(ctx.destination); s.start(ctx.currentTime + delay);
}

export const sfx = {
  tick: () => tone(880, 0.06, 'square', 0.06),
  countdown: () => tone(520, 0.18, 'square', 0.1),
  go: () => { tone(780, 0.35, 'square', 0.12); tone(1170, 0.35, 'square', 0.08, 0, 0.02); },
  reveal: () => { tone(440, 0.12, 'triangle', 0.14); tone(660, 0.12, 'triangle', 0.14, 0, 0.1); tone(880, 0.25, 'triangle', 0.14, 0, 0.2); },
  jump: () => tone(300, 0.18, 'sine', 0.12, 380),
  land: () => noise(0.06, 0.06),
  push: () => { noise(0.12, 0.16); tone(140, 0.15, 'sawtooth', 0.12, -60); },
  hit: () => { noise(0.18, 0.2); tone(110, 0.2, 'square', 0.12, -50); },
  pad: () => tone(260, 0.3, 'sine', 0.14, 700),
  fall: () => tone(700, 0.7, 'sine', 0.1, -600),
  out: () => { tone(330, 0.25, 'sawtooth', 0.12, -200); tone(200, 0.4, 'sawtooth', 0.12, -120, 0.2); },
  pickup: () => { tone(900, 0.1, 'triangle', 0.12); tone(1350, 0.18, 'triangle', 0.12, 0, 0.08); },
  power: () => { [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.16, 'triangle', 0.13, 0, i * 0.07)); },
  ability: () => { tone(200, 0.35, 'sawtooth', 0.1, 600); noise(0.2, 0.08); },
  warn: () => tone(180, 0.35, 'square', 0.1),
  win: () => { [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, 0.25, 'triangle', 0.15, 0, i * 0.12)); },
  lose: () => { [392, 349, 311, 262].forEach((f, i) => tone(f, 0.3, 'sawtooth', 0.1, 0, i * 0.16)); },
  click: () => tone(640, 0.05, 'square', 0.05),
};
