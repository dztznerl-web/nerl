// DOM helpers: screen switching, modals, toasts, safe text rendering (never innerHTML with user data).
export const $ = (id) => document.getElementById(id);

export function show(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('active', s.id === 'screen-' + id || s.id === 's-' + id));
  document.querySelectorAll('.screen.active').forEach(s => { s.scrollTop = 0; });
}

export function toast(text, ms = 1600, cls = '') {
  const el = $('hud-toast');
  if (!el) return;
  el.textContent = text;
  el.className = 'toast ' + cls;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.className = 'toast hidden'; }, ms);
}

export function modal(text, okLabel = 'تمام') {
  return new Promise((resolve) => {
    $('modal-text').textContent = text;
    $('modal-ok').textContent = okLabel;
    $('modal').classList.remove('hidden');
    $('modal-ok').onclick = () => { $('modal').classList.add('hidden'); resolve(); };
  });
}

export function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'style') n.style.cssText = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const kid of kids) {
    if (kid == null) continue;
    n.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return n;
}

export function vibrate(ms) { try { navigator.vibrate && navigator.vibrate(ms); } catch { /* ignore */ } }
