// Visual themes only. Gameplay lives on the server; the client draws what the server says.
export const THEMES = {
  neon_city:     { sky: 0x0a0020, fog: 0x1a0040, ground: 0x120033, glow: 0x00f0ff, light: 0x66e6ff, kind: 'neon' },
  lava_kingdom:  { sky: 0x2a0800, fog: 0x4a1200, ground: 0x1c0a05, glow: 0xff5a1f, light: 0xffa040, kind: 'lava' },
  ice_world:     { sky: 0xbfe8ff, fog: 0xdff4ff, ground: 0x9fd4f0, glow: 0xffffff, light: 0xe6f7ff, kind: 'ice' },
  sky_islands:   { sky: 0x6ec6ff, fog: 0xcfeeff, ground: 0x7bd36b, glow: 0xffffff, light: 0xffffff, kind: 'sky' },
  candy_land:    { sky: 0xffd1f0, fog: 0xffe6f7, ground: 0xff9fd8, glow: 0xfff29e, light: 0xffffff, kind: 'candy' },
  cyber_arena:   { sky: 0x00121f, fog: 0x002b45, ground: 0x001a2b, glow: 0x00ffa6, light: 0x40ffc0, kind: 'cyber' },
  ancient_temple:{ sky: 0xe8c98a, fog: 0xd9b779, ground: 0x8a6b3f, glow: 0xffd27a, light: 0xfff0c0, kind: 'temple' },
};
export function themeFor(id) { return THEMES[id] || THEMES.neon_city; }
