// Touch + keyboard input. Produces normalized movement vectors and button presses. The server validates everything.
export class Input {
  constructor(stickEl, knobEl, buttons, onPress) {
    this.stick = stickEl; this.knob = knobEl; this.mx = 0; this.mz = 0; this.run = false; this.onPress = onPress;
    this.keys = new Set();
    this.pointerId = null; this.cx = 0; this.cy = 0; this.radius = 50;
    stickEl.addEventListener('pointerdown', (e) => this._down(e));
    stickEl.addEventListener('pointermove', (e) => this._move(e));
    stickEl.addEventListener('pointerup', (e) => this._up(e));
    stickEl.addEventListener('pointercancel', (e) => this._up(e));
    for (const [id, action] of Object.entries(buttons)) {
      const el = document.getElementById(id);
      if (!el) continue;
      if (action === 'run') {
        el.addEventListener('pointerdown', () => { this.run = true; el.classList.add('on'); });
        const off = () => { this.run = false; el.classList.remove('on'); };
        el.addEventListener('pointerup', off); el.addEventListener('pointercancel', off); el.addEventListener('pointerleave', off);
      } else {
        el.addEventListener('pointerdown', (e) => { e.preventDefault(); this.onPress(action); });
      }
    }
    window.addEventListener('keydown', (e) => this._key(e, true));
    window.addEventListener('keyup', (e) => this._key(e, false));
    window.addEventListener('blur', () => { this.keys.clear(); this._release(); });
  }
  _down(e) {
    this.pointerId = e.pointerId;
    const r = this.stick.getBoundingClientRect();
    this.cx = r.left + r.width / 2; this.cy = r.top + r.height / 2; this.radius = r.width / 2 - 26;
    this.stick.setPointerCapture(e.pointerId);
    this._move(e);
  }
  _move(e) {
    if (e.pointerId !== this.pointerId) return;
    let dx = e.clientX - this.cx, dy = e.clientY - this.cy;
    const d = Math.hypot(dx, dy);
    if (d > this.radius) { dx *= this.radius / d; dy *= this.radius / d; }
    this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    this._set(dx / this.radius, dy / this.radius);
  }
  _up(e) {
    if (e.pointerId !== this.pointerId) return;
    this.pointerId = null;
    this.knob.style.transform = '';
    this._release();
  }
  _release() { this._set(0, 0); }
  _key(e, down) {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D', ' ', 'f', 'e', 'Shift'].indexOf(e.key) < 0) return;
    if (down) this.keys.add(e.key); else this.keys.delete(e.key);
    if (down && e.key === ' ') { e.preventDefault(); this.onPress('jump'); }
    if (down && (e.key === 'f' || e.key === 'F')) this.onPress('push');
    if (down && (e.key === 'e' || e.key === 'E')) this.onPress('ability');
    this.run = this.keys.has('Shift');
    let x = 0, z = 0;
    if (this.keys.has('ArrowLeft') || this.keys.has('a') || this.keys.has('A')) x -= 1;
    if (this.keys.has('ArrowRight') || this.keys.has('d') || this.keys.has('D')) x += 1;
    if (this.keys.has('ArrowUp') || this.keys.has('w') || this.keys.has('W')) z -= 1;
    if (this.keys.has('ArrowDown') || this.keys.has('s') || this.keys.has('S')) z += 1;
    if (x || z) this._set(x, z); else if (this.pointerId === null) this._set(0, 0);
  }
  _set(x, z) {
    const m = Math.hypot(x, z);
    if (m > 1) { x /= m; z /= m; }
    this.mx = x; this.mz = z;
  }
}
