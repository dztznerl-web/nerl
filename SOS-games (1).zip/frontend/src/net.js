// Auth + WebSocket client with automatic reconnect (the server keeps your slot for a grace period).
export async function authenticate() {
  const tg = window.Telegram && window.Telegram.WebApp;
  const initData = tg ? tg.initData : '';
  if (!initData) throw new Error('افتح اللعبة من داخل تيليجرام');
  const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ init_data: initData }) });
  if (r.status === 403) throw new Error('حسابك محظور');
  if (!r.ok) throw new Error('فشل التحقق من الحساب');
  return r.json();
}

export async function api(path, token, opts = {}) {
  const r = await fetch(path, { ...opts, headers: { ...(opts.headers || {}), Authorization: 'Bearer ' + token } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

export class Net {
  constructor(token, handlers) {
    this.token = token; this.h = handlers; this.ws = null; this.closed = false; this.retry = 0; this.rtt = 0; this.pingTimer = null;
  }
  connect() {
    if (this.closed) return;
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/ws`);
    this.ws = ws;
    ws.onopen = () => {
      ws.send(JSON.stringify({ t: 'auth', token: this.token }));
      this.retry = 0;
      this.h.status && this.h.status(true);
      clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => this.send({ t: 'ping', c: performance.now() }), 4000);
    };
    ws.onmessage = (ev) => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m.t === 'pong') { this.rtt = performance.now() - m.c; return; }
      this.h.message && this.h.message(m);
    };
    ws.onclose = () => {
      clearInterval(this.pingTimer);
      this.h.status && this.h.status(false);
      if (this.closed) return;
      const delay = Math.min(8000, 500 * 2 ** this.retry++);
      setTimeout(() => this.connect(), delay);
    };
    ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
  }
  send(obj) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(obj)); }
  close() { this.closed = true; clearInterval(this.pingTimer); if (this.ws) this.ws.close(); }
}
