// Run with: node --test frontend/tests/
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { rowOffset, tileCenter, lerpAngle, sweeperAngle, hex, CHAR_COLORS } from '../src/shared.js';

test('tileCenter is centred on origin for odd and even grids', () => {
  const [x0, z0] = tileCenter(0, 4, 3);
  assert.equal(x0, -4.5); assert.equal(z0, -4.5);
  const [xl, zl] = tileCenter(15, 4, 3);
  assert.equal(xl, 4.5); assert.equal(zl, 4.5);
});

test('rowOffset is zero for static rows and bounded by amplitude', () => {
  assert.equal(rowOffset(0, 1, 0, 3), 0);
  assert.equal(rowOffset(2.2, 0.8, undefined, 3), 0);
  for (let t = 0; t < 20; t += 0.37) assert.ok(Math.abs(rowOffset(2.2, 0.8, 0, t)) <= 2.2 + 1e-9);
});

test('lerpAngle takes the short way round', () => {
  const v = lerpAngle(Math.PI - 0.1, -Math.PI + 0.1, 0.5);
  assert.ok(Math.abs(Math.abs(v) - Math.PI) < 0.01);
});

test('sweeper angles are evenly spaced', () => {
  const a = sweeperAngle(0, 4, 1, 0), b = sweeperAngle(1, 4, 1, 0);
  assert.ok(Math.abs((b - a) - Math.PI / 2) < 1e-9);
});

test('hex parsing and colour palette are valid', () => {
  assert.equal(hex('#ff3b5c'), 0xff3b5c);
  for (const c of CHAR_COLORS) assert.match(c, /^#[0-9a-f]{6}$/i);
});
